// PingServer.java
import java.io.*;
import java.net.*;
import java.util.*;
/*
 * Server to process ping requests over UDP.
 */

public class PingServer
{
    private static double LOSS_RATE = 0.3;
    private static int AVERAGE_DELAY = 100;
    private static String PASSWD;
    public static void main(String[] args) throws Exception
    {
        // Get command line argument.
        if (args.length < 2) {
            System.out.println("Required arguments: port passwd [-delay delay] [-loss loss]");
            return;
        }
        PASSWD=args[1];
        if(args.length==6&&args[2].equals("[-delay")&&args[4].equals("[-loss")){
            AVERAGE_DELAY=Integer.parseInt(args[3].substring(0,args[3].length()-1));
            LOSS_RATE=Double.parseDouble(args[5].substring(0,args[5].length()-1));
        }
        else if(args.length==6&&args[4].equals("[-delay")&&args[2].equals("[-loss")){
            AVERAGE_DELAY=Integer.parseInt(args[5].substring(0,args[5].length()-1));
            LOSS_RATE=Double.parseDouble(args[3].substring(0,args[3].length()-1));
        }
        else if(args.length==4&&args[2].equals("[-delay")){
            AVERAGE_DELAY=Integer.parseInt(args[3].substring(0,args[3].length()-1));
        }
        else if(args.length==4&&args[2].equals("[-loss")){
            LOSS_RATE=Double.parseDouble(args[3].substring(0,args[3].length()-1));
        }
        //print loss, delay for test
        System.out.println("Welcome!"+"\n");
        System.out.println("delay:"+AVERAGE_DELAY+"\n");
        System.out.println("loss:"+LOSS_RATE+"\n");
        // change String to int
        int port = Integer.parseInt(args[0]);
        // Create random number generator for use in simulating
        // packet loss and network delay.
        Random random = new Random();

        //progress to get packet:
        //1.new a socket and firm to a port
        //2.use datagrampacket to bulid a byte array to receive packet
        //3.use receive() method to get udp packet

        // Create a datagram socket for receiving and sending
        // UDP packets through the port specified on the
        // command line.
        DatagramSocket socket = new DatagramSocket(port);

        // Processing loop.
        while (true) {
            //to get a packet 1024
            // Create a datagram packet to hold incomming UDP packet.
            DatagramPacket
                    request = new DatagramPacket(new byte[1024], 1024);

            // Block until receives a UDP packet.
            socket.receive(request);

            // Print the received data, for debugging
            printData(request);

            // Decide whether to reply, or simulate packet loss.
            if (random.nextDouble() < LOSS_RATE) {
                System.out.println(" Reply not sent.");
                continue;
            }

            // Simulate prorogation delay.
            Thread.sleep((int) (random.nextDouble() * 2 * AVERAGE_DELAY));

            // Send reply.
            InetAddress clientHost = request.getAddress();
            int clientPort = request.getPort();
            byte[] buf = request.getData();
            String message=new String(buf);
            //get passwd
            System.out.println(message.length());
            int firstspace=message.indexOf(" ");
            int secondspace=message.indexOf(" ",firstspace+1);
            int thirdspace=message.indexOf(" ",secondspace+1);
            int lastword=message.indexOf(0);
            String passwd=message.substring(thirdspace+1,lastword-2);
            System.out.println(passwd);
            if(!passwd.equals(PASSWD)){
                System.out.println(" Reject.");
                continue;
            }
            message="PINGECHO "+message.substring(5);

            buf=message.getBytes();
            DatagramPacket
                    reply = new DatagramPacket(buf, buf.length,
                    clientHost, clientPort);

            socket.send(reply);

            System.out.println(" Reply sent.");
        } // end of while
    } // end of main

    /*
     * Print ping data to the standard output stream.
     */
    private static void printData(DatagramPacket request)
            throws Exception

    {
        // Obtain references to the packet's array of bytes.
        byte[] buf = request.getData();

        // Wrap the bytes in a byte array input stream,
        // so that you can read the data as a stream of bytes.
        ByteArrayInputStream bais
                = new ByteArrayInputStream(buf);

        // Wrap the byte array output stream in an input
        // stream reader, so you can read the data as a
        // stream of **characters**: reader/writer handles
        // characters
        InputStreamReader isr
                = new InputStreamReader(bais);

        // Wrap the input stream reader in a bufferred reader,
        // so you can read the character data a line at a time.
        // (A line is a sequence of chars terminated by any
        // combination of \r and \n.)
        BufferedReader br
                = new BufferedReader(isr);

        // The message data is contained in a single line,
        // so read this line.
        String line = br.readLine();

        // Print host address and data received from it.
        System.out.println("Received from " +
                request.getAddress().getHostAddress() +
                ": " +
                new String(line) );
    } // end of printData
} // end of class