// PingClient.java
import java.io.*;
import java.net.*;
import java.util.*;

/*
 * Client to ping
 */

public class PingClient {
    private static final int TIME_OUT=1000;
    private static final int PORT=1025;

    public static void main(String[] args) throws Exception {
        // Get command line argument.
        if (args.length != 3) {
            System.out.println("Required arguments: host, port and passwd");
            return;
        }
        //get argument
        InetAddress host=InetAddress.getByName(args[0]);
        int port = Integer.parseInt(args[1]);
        String passwd=args[2];
        //set sequence_number, loss, and RTTs
        int sequence_number=1;
        double loss=0;
        double minRTT=Double.MAX_VALUE,maxRTT=Double.MIN_VALUE,averageRTT=0.0;
        // Create a datagram socket for receiving and sending
        DatagramSocket socket = new DatagramSocket(PORT);
        //set timeout
        socket.setSoTimeout(TIME_OUT);
        // Processing loop for 10 times.
        while (sequence_number<=10) {

            // Send request.
            byte[] buf = new byte[1024];
            Date date = new Date();
            long timestamp=date.getTime() ;
            String message="PING "+sequence_number+" "+timestamp+" "+passwd+"\r\n";
            buf=message.getBytes();
            DatagramPacket
                    request = new DatagramPacket(buf, buf.length,
                    host, port);
            socket.send(request);
            System.out.println(" Request sent.");

            //get reply
            DatagramPacket
                    reply = new DatagramPacket(new byte[1024], 1024);
            try{
                socket.receive(reply);
                date=new Date();
                long delay=date.getTime()-timestamp;
                minRTT=minRTT<delay?minRTT:delay;
                maxRTT=maxRTT<delay?delay:maxRTT;
                averageRTT+=delay;
                printData(reply);
            }
            catch (SocketTimeoutException e){
                System.out.println("loss:"+message.substring(0,message.length()-2));
                loss+=1.0;

            }
            // Create a datagram packet to hold incomming UDP packet.
            sequence_number++;
            //wait for 1s
            Thread.sleep(1000);
        } // end of while
        loss/=10.0;
        averageRTT/=10.0;
        System.out.print("min RTT:"+minRTT+"ms\n");
        System.out.print("max RTT:"+maxRTT+"ms\n");
        System.out.print("average RTT:"+averageRTT+"ms\n");
        System.out.print("loss rate:"+loss+"\n");
    } // end of main

    /*
     * Print ping data to the standard output stream.
     */
    private static void printData(DatagramPacket reply)
            throws Exception {
        // Obtain references to the packet's array of bytes.
        byte[] buf = reply.getData();

        // Wrap the bytes in a byte array input stream,
        // so that you can read the data as a stream of bytes.
        ByteArrayInputStream bais
                = new ByteArrayInputStream(buf);

        // Wrap the byte array output stream in an input
        // stream reader, so you can read the data as a
        // stream of **characters**: reader/writer handles
        // characters
        InputStreamReader isr
                = new InputStreamReader(bais);

        // Wrap the input stream reader in a bufferred reader,
        // so you can read the character data a line at a time.
        // (A line is a sequence of chars terminated by any
        // combination of \r and \n.)
        BufferedReader br
                = new BufferedReader(isr);

        // The message data is contained in a single line,
        // so read this line.
        String line = br.readLine();

        // Print host address and data received from it.
        System.out.println("Received from " +
                reply.getAddress().getHostAddress() +
                ": " +
                new String(line) );
    } // end of printData
} // end of class