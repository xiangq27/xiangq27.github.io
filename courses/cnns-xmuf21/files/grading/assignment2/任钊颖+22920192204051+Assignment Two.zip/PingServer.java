//使用 java PingServer [port] 的格式启动
//例如 java PingServer 2222

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Random;
 
public class PingServer {
	private static final double LOSS_RATE = 0.3;
	private static final int AVERAGE_DELAY = 100;
	public static void main(String[] args) throws Exception{
		//服务器密码
		String rpasswd = "Rzy"; 
		//端口不对
		if(args.length != 1){
			System.out.println("Required arguments:port");
			return;
		}
		//开始
		System.out.println("PingServer: \n The passwd is : Rzy . \r\n");
		//端口
		int port = Integer.parseInt(args[0]);
		//创造随机数用来模拟丢包和网络延迟
		Random random = new Random();
		DatagramSocket socket = new DatagramSocket(port);
		//不断循环，接收请求
		while(true){
			//创造一个packet以接收收到的udp包
			DatagramPacket request = new DatagramPacket(new byte[1024], 1024); 
			socket.receive(request);
			//取出包的内容
			byte[] buffer0 = request.getData();
			ByteArrayInputStream bais = new ByteArrayInputStream(buffer0);
			InputStreamReader isr = new InputStreamReader(bais);
			BufferedReader br = new BufferedReader(isr);
			String line = br.readLine();
			//将内容按空格分开
			String sim[] = line.split(" ");
			//根据消息格式，sim[4]是密码
			String passwd = new String(sim[4]);
			//用密码判断，密码不正确则不回应
 			if(passwd.equals(rpasswd) == false ){
 				System.out.println("Wrong passwd!");
 				continue;
 			}
 			//输出信息
			System.out.println("Received from" + request.getAddress().getHostAddress()+": "+ new String(sim[0]) + " " + new String(sim[1]) +" " + new String(sim[2]) + " passwd:" + new String(sim[4]) );
			//小于丢包率的不回应
			if(random.nextDouble()<LOSS_RATE){
				System.out.println("Reply not sent");
				continue;
			}
			Thread.sleep((int)(random.nextDouble()*2*AVERAGE_DELAY));
			
			//回应
			InetAddress clientHost = request.getAddress();
			int clientPort = request.getPort();
			byte[] buffer = request.getData();
			DatagramPacket reply = new DatagramPacket(buffer, buffer.length,clientHost,clientPort);
			socket.send(reply);
			
			System.out.println("Reply sent");
		}
	}
}

