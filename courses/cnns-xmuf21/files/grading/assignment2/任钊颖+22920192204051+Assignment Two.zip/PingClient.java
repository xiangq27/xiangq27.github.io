//使用 java PingClient [host] [port] [passwd] 的格式启动
//例如 java PingClient localhost 2222 abcd

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Date;
import java.text.SimpleDateFormat;
 
public class PingClient {
	
	public static void main(String[] args) throws Exception{
		//如果控制台输入数据为空 则返回。控制台输入数据用空格隔开，存储在args数组里
		if(args.length == 0){
			System.out.println("Required arguments:host port");
			return;
		}
		//定义并初始化接收到的响应报文的个数
		int replyNum = 0;
		//定义并初始化最小往返时间、最大往返时间、平均往返时间
		long minRtt = 0, maxRtt = 0, averRtt = 0,sumRtt = 0,lossRate=0;
		//每一个请求对应的rtt，默认初始化为0
		long[] rtt = new long[10];
		//IP 地址
		String host = args[0].toString();
		//端口
		int port = Integer.parseInt(args[1]);
		//密码
		String passwd = new String(args[2]);
		//clientSocket
		DatagramSocket clientSocket = new DatagramSocket();
		//设置等待server回答的时间，以ms为单位。如果是0，则无限等待
		clientSocket.setSoTimeout(1000);
		//InetAddress
		InetAddress IPAddress = InetAddress.getByName(host);
		//发送10个请求
		for(int i = 0;i<10;i++){
			//发送的data
			byte[] sendData = new byte[1024];
			//接收的data
			byte[] receiveData = new byte[1024];
			//时间戳
			Date currentTime = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String timeStamp = sdf.format(currentTime);
			//定义ping，发送出的数据
			String pingMessage = "Ping" + i + " " + timeStamp + " " + "passwd: " + passwd + " ";
			sendData = pingMessage.getBytes();
			//发送前时间
			Date sendTime = new Date();
			//打包
			DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length,IPAddress,port);
			//发送
			try{
				//发送
				clientSocket.send(sendPacket);
				//接收
				DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
				clientSocket.receive(receivePacket);
				//将接受得到的内容拿出来
				String reply = new String(receivePacket.getData());
				//接收时间
				Date receiveTime = new Date();
				//计算往返时间
				rtt[i] = receiveTime.getTime()-sendTime.getTime();
				//输出
				System.out.println("PINGECHO "+reply);
				//如果发送失败（超时或者是密码不对）
			}catch(java.net.SocketTimeoutException e){
				//直接将时间给到1000ms以上，表示这条请求失败
				rtt[i]=1002;
				//输出失败的信息
				String reply = "Ping" + i + " " + timeStamp + " passwd: " + passwd+ " No reply!";
				System.out.println("PINGECHO " + reply);
			}
		}
		//关闭客户端
		clientSocket.close();
		//计算相应的时间值
		minRtt = rtt[0];
		for(int i=0;i<10;i++) {
			if(rtt[i] > 1000)  continue;//请求失败不计算往返时间
			replyNum++;	
			//计算最小往返时间
			if(minRtt > rtt[i]) {
				minRtt = rtt[i];
			}
			//计算最大往返时间
			if(maxRtt < rtt[i]) {
				maxRtt = rtt[i];
			}
			//计算总往返时间
			sumRtt += rtt[i];
		}
		if(replyNum!=0) {
			//计算平均往返时间
			averRtt = sumRtt/replyNum;
			//输出发送成功及失败的个数，计算丢包率
			System.out.println("Ping statistics for " + IPAddress + ":");
			System.out.println("	Packets: Sent=10, Received=" + replyNum +", Lost=" + (10-replyNum) + ", Loss Rate=" + ((10-replyNum)*10) + "%");
			//输出最长、最短、平均用时
			System.out.println("Approximate round trip times in milli-seconds:");
			System.out.println("	minRTT:" + minRtt + "ms, maxRTT:" + maxRtt + "ms, averRTT:" + averRtt + "ms");
		}else {
			//没能成功发送请求，输出信息
			System.out.println("Failed to send request! Unable to return message!");
		}
	}
}
