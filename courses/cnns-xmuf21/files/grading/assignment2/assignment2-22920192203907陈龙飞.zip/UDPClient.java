import java.net.Socket;
import java.net.UnknownHostException;
import java.io.*;
import java.net.*;
import java.util.*;
import java.text.SimpleDateFormat;

public class UDPClient {
    public static void main(String[] args) throws IOException {
        InetAddress address = InetAddress.getByName(args[0]);
        int port = Integer.parseInt(args[1]);
        String passwd=new String(args[2]);
        long[] rtt={0,0,0,0,0,0,0,0,0,0};
        int number=0;
	//System.out.println(address);
	//System.out.println(port);
	//System.out.println(passwd);
	String ping="PING";
	for(int i=0;i<10;i++)
      {
        short sequence_number=(short)i;
        String num=String.valueOf(i);

	long timestamp=System.currentTimeMillis();
	String time=Long.toString(timestamp);

        //String RFLT=" \r\n";

        String dataa=ping+" "+num+" "+time+" "+passwd;//System.out.println(dataa);
        byte[] data = dataa.getBytes();
       
        DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
       
        DatagramSocket socket = new DatagramSocket();
      
        socket.setSoTimeout(2000);
        long pre=System.currentTimeMillis();
	Timer mTimer=new Timer();
        mTimer.schedule(new myClass(packet,socket),1000);
        //socket.send(packet);
        //Thread.sleep(1000);

        
        byte[] data2 = new byte[1024];
        DatagramPacket packet2 = new DatagramPacket(data2, data2.length);
       
        try {socket.receive(packet2);}
        catch(Exception e) {System.out.println("the packet lossed,goto next one...");number--;}
        long after=System.currentTimeMillis();
        rtt[i]=after-pre;
        
        String reply = new String(data2, 0, packet2.getLength());
        System.out.println("This is client,the server reply:" + reply);
        number++;
       
        socket.close();
      }
      long total=0;
      long max=0;
      long min=rtt[0];
      for(int i=0;i<10;i++)
      {
      if(rtt[i]<2000) total=total+rtt[i];
      if(rtt[i]>max&&rtt[i]<2000) max=rtt[i];
      if(rtt[i]<min) min=rtt[i];
      }
      System.out.println("Max:"+(max-1000)+"ms min:"+(min-1000)+"ms average:"+(total/number-1000)+"ms");
      System.out.println("the successful transmission rate:"+(double)number/10);
    }
}
class myClass extends TimerTask {
	Timer timer=null;
	private DatagramPacket packet;
	private DatagramSocket socket;
	public myClass(DatagramPacket packet,DatagramSocket socket)
	{
		this.packet=packet;
		this.socket=socket;
	}
	public void run() {
	  try{socket.send(packet);}
   	  catch(Exception e) {System.out.println("error");}
   	  try {timer.cancel();}
   	  catch(Exception e) {}
	}
}

