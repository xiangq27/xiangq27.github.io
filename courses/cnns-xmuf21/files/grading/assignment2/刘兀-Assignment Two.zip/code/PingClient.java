// PingClient.java
//import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;

import java.io.*;
import java.net.*;
import java.util.*;

import java.util.concurrent.locks.*;

public class PingClient {
    static String serverName;
    static InetAddress serverIPAddress;
    static int serverPort;
    static String passwd;
    static int loss = 0;

    static DatagramSocket clientSocket;

    public static void main(String[] args) throws Exception{
        if(args.length != 3){
            System.out.println("usage: java PingClient host port passwd");
            return;
        }

        serverName = args[0];
        serverIPAddress = InetAddress.getByName(serverName);

        serverPort = Integer.parseInt(args[1]);

        passwd = args[2];

        clientSocket = new DatagramSocket();
        clientSocket.setSoTimeout(1000);

        //Start Ping
        Timer mTimer = new Timer();
        mTimer.schedule(new PingTask(mTimer),0,1000);

    }
}

class PingTask extends TimerTask{

    static int task = 0;
    private  Timer timer;
    static Lock lock = new ReentrantLock();
    static long MaxRTT=0;
    static long MinRTT=0xffff;
    static long SumRTT=0;
    static int receivedTask=0;

    public PingTask(Timer timer){
        this.timer = timer;
    }

    @Override
    public void run(){

        task++;

        if(task >= 11){
            this.timer.cancel();
            System.out.println(" Total Loss:"+PingClient.loss);
            if(receivedTask>0) System.out.println(" MaxRTT:"+MaxRTT+"ms MinRTT:"+MinRTT+"ms AveRTT:"+SumRTT/receivedTask+"ms");
            System.out.println(" Loss rate:"+PingClient.loss*1.0/10*100+'%');

            PingClient.clientSocket.close();
        }

        long totalMilliSeconds = System.currentTimeMillis();
        long totalSeconds = totalMilliSeconds / 1000;   
        
        long currentSecond = totalSeconds % 60;
          
        long totalMinutes = totalSeconds / 60;
        long currentMinute = totalMinutes % 60;
         
        
        long totalHour = totalMinutes / 60;
        long currentHour = totalHour % 24;

        
        String message = "PING "+task+' '+currentHour+':'+currentMinute+':'+currentSecond+" "+PingClient.passwd+" \n";
        
        //Encode
        byte[] sendData;
        try {
            sendData = message.getBytes("UTF-8");
        } catch (UnsupportedEncodingException e1) {
            System.out.println("UnsupportedEncoding\n");
            return;
        }
         
        DatagramPacket sendPacket = new DatagramPacket(sendData,sendData.length,PingClient.serverIPAddress,PingClient.serverPort);
        long sendTime = System.currentTimeMillis();
        try {
            
            PingClient.clientSocket.send(sendPacket);
        } catch (IOException e) {

        }

        byte[] receiveData = new byte[1024];
        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

        long receiveTime=0;
        try{
            PingClient.clientSocket.receive(receivePacket);
            receiveTime = System.currentTimeMillis();

        }catch (IOException e){
            PingClient.loss++;
            return;
        }

        String messageFromServer = new String(receivePacket.getData());
        
        byte[] buf = receivePacket.getData();

        //Decode
        ByteArrayInputStream bais
                = new ByteArrayInputStream(buf);

        InputStreamReader isr;
        try {
            isr = new InputStreamReader(bais, "UTF-8");
        } catch (UnsupportedEncodingException e1) {
            System.out.println("UnsupportedEncoding");
            return;
        }

        BufferedReader br
                = new BufferedReader(isr);

        try {
            String line = br.readLine();
            messageFromServer=line;
        } catch (IOException e) {
            return;
        }
        
        long RTT=receiveTime-sendTime;
        MaxRTT=RTT>MaxRTT?RTT:MaxRTT;
        MinRTT=RTT<MinRTT?RTT:MinRTT;
        SumRTT+=RTT;
        receivedTask++;
        System.out.println("From Server: "+ messageFromServer+"\n RTT: "+RTT+"ms\n");
    }
}
