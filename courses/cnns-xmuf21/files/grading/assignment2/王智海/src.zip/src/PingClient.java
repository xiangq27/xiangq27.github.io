import java.io.*;
import java.net.*;
import java.util.*;

public class PingClient {
    private static final int TIMEOUT = 1000; // milliseconds
    private static final int MAX_PING_REQUEST = 10; // Numero de ping requests
    private static final int CLIENT_PORT = 5000;
    private static InetAddress serverHost = null;
    private static int serverPort = 0;
    private static DatagramSocket socket = null;
    private static int passwd = 0;
    private static long MIN_DELAY = 200;
    private static long MAX_DELAY = 0;
    private static int CNT = 0;
    private static double loss = 0.0;
    private static double FLAG = 0.0;

    public static void main(String[] args) throws Exception {

        if (args.length != 3) {
            System.out.println("Required arguments: host port password");
            return;
        }

        serverHost = InetAddress.getByName(args[0]);
        serverPort = Integer.parseInt(args[1]);
        passwd  = Integer.parseInt(args[2]);

        socket = new DatagramSocket(CLIENT_PORT);
        socket.setSoTimeout(TIMEOUT);

        int sequence_number = -1;
        while (++sequence_number < MAX_PING_REQUEST) {
            DatagramPacket response = new DatagramPacket(new byte[1024], 1024);

            Date date = new Date();
            long timestamp = date.getTime();

            String sendMessage = "PING " + sequence_number + " " + timestamp + " Password " + passwd + " \r\n";

            byte[] buffer = new byte[1024];
            buffer = sendMessage.getBytes();

            DatagramPacket pingRequest = new DatagramPacket(buffer, buffer.length, serverHost, serverPort);
            socket.send(pingRequest);

            CNT = CNT + 1;

            try {
                socket.receive(response);

                date = new Date();
                long delayReceived = date.getTime() - timestamp;

                System.out.print("Delay " + delayReceived + " ms: ");

                if(delayReceived <  MIN_DELAY){
                    MIN_DELAY = delayReceived;
                }

                if(delayReceived > MAX_DELAY){
                    MAX_DELAY = delayReceived;
                }


                printData(response);
            }
            catch (SocketTimeoutException e) {
                FLAG = FLAG + 1;
                System.out.println("Pacote perdido: " + sendMessage);
            }
            loss = FLAG/10;
            if(CNT == 10){
                System.out.print("Min_Delay " + MIN_DELAY + " ms: ");
                System.out.print("Max_Delay " + MAX_DELAY + " ms: ");
                System.out.print("Loss: "+ loss + " ");
            }
        }
    }


    private static void printData(DatagramPacket request) throws Exception {

        byte[] buf = request.getData();

        ByteArrayInputStream bais = new ByteArrayInputStream(buf);

        InputStreamReader isr = new InputStreamReader(bais);

        BufferedReader br = new BufferedReader(isr);

        String line = br.readLine();

        System.out.println("Received from " + request.getAddress().getHostAddress() + ": " + new String(line));
    }
}