
// PingServer.java
import java.net.*;
import java.util.*;

/* 
 * Server to process ping requests over UDP.
 */

public class PingServer {
   public static short sequence_number = 0;
   public static long client_send_time = 0;
   public static String client_passwd = "";
   public static double LOSS_RATE = 0.3;
   public static int AVERAGE_DELAY = 100; // milliseconds

   public static void main(String[] args) throws Exception {
      int len = args.length;
      // Get command line argument.
      if (len < 2) {
         System.out.println("Missing parameters");
         return;
      }
      int port = Integer.parseInt(args[0]);
      String passwd = args[1];
      switch (len) {
      case 2:
         break;
      case 3:
         LOSS_RATE = Double.parseDouble(args[2]);
         AVERAGE_DELAY = 100; // milliseconds
         break;
      case 4:
         LOSS_RATE = Double.parseDouble(args[2]);
         AVERAGE_DELAY = Integer.parseInt(args[3]); // milliseconds
         break;
      default:
         System.out.println("Excessive parameters");
         return;
      }

      // Create random number generator for use in simulating
      // packet loss and network delay.
      Random random = new Random();

      // Create a datagram socket for receiving and sending
      // UDP packets through the port specified on the
      // command line.
      DatagramSocket serverSocket = new DatagramSocket(port);

      // Processing loop.
      while (true) {
         // Create a datagram packet to hold incoming UDP packet.
         DatagramPacket request = new DatagramPacket(new byte[14 + passwd.length() + 2], 14 + passwd.length() + 2);

         // Block until receives a UDP packet.
         serverSocket.receive(request);

         long start = System.currentTimeMillis();

         // Print the received data, for debugging
         printData(request);

         if (!passwd.equals(client_passwd)) {
            System.out.println(" Password error! Reply not sent.");
            continue;
         }

         // Decide whether to reply, or simulate packet loss.
         if (random.nextDouble() < LOSS_RATE) {
            System.out.println(" Reply not sent.");
            continue;
         }
         // Simulate prorogation delay.
         Thread.sleep((int) (random.nextDouble() * 2 * AVERAGE_DELAY));

         // Send reply.
         InetAddress clientHost = request.getAddress();
         int clientPort = request.getPort();

         byte[] send1 = "PINGECHO".getBytes();
         byte[] buf = request.getData();
         byte[] send2 = Arrays.copyOfRange(buf, 4, buf.length);

         byte[] sendData = byteMerger(send1, send2);

         DatagramPacket reply = new DatagramPacket(sendData, sendData.length, clientHost, clientPort);

         serverSocket.send(reply);

         System.out.println(" Reply sent.");

         long end = System.currentTimeMillis();
         if (end - start >= 1000000) {
            System.out.println("\r\nNo operation in a long time, automatically close serverSocket.");
            serverSocket.close();
            break;
         }
      } // end of while
   } // end of main

   /*
    * Print ping data to the standard output stream.
    */
   private static void printData(DatagramPacket request) throws Exception {
      // Obtain references to the packet's array of bytes.
      byte[] buf = request.getData();

      String ping = new String(Arrays.copyOfRange(buf, 0, 4));
      sequence_number = BytesToShort(Arrays.copyOfRange(buf, 4, 6));
      client_send_time = BytesToLong(Arrays.copyOfRange(buf, 6, 14));
      client_passwd = new String(Arrays.copyOfRange(buf, 14, buf.length - 2));
      String crlf = new String(Arrays.copyOfRange(buf, buf.length - 2, buf.length));

      // Print host address and data received from it.
      System.out.println("Received from " + request.getAddress().getHostAddress() + ": " + ping + ' ' + sequence_number
            + ' ' + client_send_time + ' ' + client_passwd + crlf);

   } // end of printData

   public static short BytesToShort(byte[] buffer) {
      short values = 0;
      for (int i = 0; i < 2; i++) {
         values <<= 8;
         values |= (buffer[i] & 0xff);
      }
      return values;
   }// end of BytesToShort

   public static long BytesToLong(byte[] buffer) {
      long values = 0;
      for (int i = 0; i < 8; i++) {
         values <<= 8;
         values |= (buffer[i] & 0xff);
      }
      return values;
   }// end of BytesToLong

   public static byte[] byteMerger(byte[] bt1, byte[] bt2) {
      byte[] bt3 = new byte[bt1.length + bt2.length];
      System.arraycopy(bt1, 0, bt3, 0, bt1.length);
      System.arraycopy(bt2, 0, bt3, bt1.length, bt2.length);
      return bt3;
   }// end of byteMerger

} // end of class