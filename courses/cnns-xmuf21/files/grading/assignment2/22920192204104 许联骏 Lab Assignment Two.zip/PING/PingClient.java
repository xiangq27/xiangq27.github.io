
//PingClient.java
import java.io.*;
import java.net.*;
import java.util.*;

public class PingClient {
	public static Double lossRate = 0.0;
	public static int fm = 0;
	public static long MaxRTT = 0;
	public static long MinRTT = 1000;
	public static long AvgRTT = 0;
	public static long TmpRTT = 0;

	public static short i = 0;

	public static void main(String[] args) throws Exception {
		if (args.length != 3) {
			System.out.println("Required arguments: serverHost serverPort passwd");
			return;
		}
		String serverHost = args[0];
		InetAddress serverIPAddress = InetAddress.getByName(serverHost);
		int serverPort = Integer.parseInt(args[1]);
		String passwd = args[2];

		DatagramSocket clientSocket = new DatagramSocket();

		clientSocket.setSoTimeout(1000);

		Timer timer = new Timer();
		timer.schedule(new TimerTask() {
			public void run() {
				if (i == 10) {
					if (fm != 0) {
						System.out.println("MAX_RTT = " + MaxRTT);
						System.out.println("MIN_RTT = " + MinRTT);
						System.out.println("AVERAGE_RTT = " + AvgRTT / fm);
						System.out.println("LOSS_RATE = " + lossRate);
					} else
						System.out.println("Unable to connect to the server.");
					// close client socket
					clientSocket.close();
					timer.cancel();
					return;
				}
				try {
					byte[] send1 = "PING".getBytes();
					byte[] send2 = ShortToBytes(i);
					byte[] sendData1 = byteMerger(send1, send2);

					long start = System.currentTimeMillis();
					byte[] send3 = LongToBytes(start);
					byte[] send4 = (passwd + "\r\n").getBytes();
					byte[] sendData2 = byteMerger(send3, send4);

					byte[] sendData = byteMerger(sendData1, sendData2);

					DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverIPAddress,
							serverPort);
					clientSocket.send(sendPacket);

					// receive datagram
					byte[] receiveData = new byte[1024];
					DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
					clientSocket.receive(receivePacket);
					// print output
					byte[] buf = receivePacket.getData();
					long end = System.currentTimeMillis();
					String sentenceFromServer = new String(Arrays.copyOfRange(buf, 0, 8)) + ' '
							+ BytesToShort(Arrays.copyOfRange(buf, 8, 10)) + ' '
							+ BytesToLong(Arrays.copyOfRange(buf, 10, 18)) + ' '
							+ new String(Arrays.copyOfRange(buf, 18, buf.length));
					System.out.println(sentenceFromServer);

					fm += 1;
					TmpRTT = end - start;
					if (MaxRTT < TmpRTT)
						MaxRTT = TmpRTT;
					if (MinRTT > TmpRTT)
						MinRTT = TmpRTT;
					AvgRTT += TmpRTT;
				} catch (SocketTimeoutException e) {
					System.out.println("Packet " + i + " loss\r\n");
					lossRate += 0.1;
				} catch (IOException e) {
					System.out.println(e);
				}
				i++;
			}// end of run
		}, 0, 1000);

	}// end of main

	public static byte[] ShortToBytes(short values) {
		byte[] buffer = new byte[2];
		for (int i = 0; i < 2; i++) {
			int offset = 16 - (i + 1) * 8;
			buffer[i] = (byte) ((values >> offset) & 0xff);
		}
		return buffer;
	}// end of ShortToByte

	public static short BytesToShort(byte[] buffer) {
		short values = 0;
		for (int i = 0; i < 2; i++) {
			values <<= 8;
			values |= (buffer[i] & 0xff);
		}
		return values;
	}// end of BytesToShort

	public static byte[] LongToBytes(long values) {
		byte[] buffer = new byte[8];
		for (int i = 0; i < 8; i++) {
			int offset = 64 - (i + 1) * 8;
			buffer[i] = (byte) ((values >> offset) & 0xff);
		}
		return buffer;
	}// end of LongToByte

	public static long BytesToLong(byte[] buffer) {
		long values = 0;
		for (int i = 0; i < 8; i++) {
			values <<= 8;
			values |= (buffer[i] & 0xff);
		}
		return values;
	}// end of BytesToLong

	public static byte[] byteMerger(byte[] bt1, byte[] bt2) {
		byte[] bt3 = new byte[bt1.length + bt2.length];
		System.arraycopy(bt1, 0, bt3, 0, bt1.length);
		System.arraycopy(bt2, 0, bt3, bt1.length, bt2.length);
		return bt3;
	}// end of byteMerger

}// end of class