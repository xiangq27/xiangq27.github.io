// PingServer.java
    import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Ping Server
 */
public class PingServer
{
	public static void main(String[] args) throws Exception
	{	
		int initPort = new Integer(args[0]);	
		String passwd = args[1];	
		DatagramSocket serverSocket = new DatagramSocket(initPort);
		//死循环，不断的监听是否有请求数据
      double LOSS_RATE = Double.parseDouble(args[2])*(-1.0);//应丢失数据包的百分比
      int AVERAGE_DELAY = Integer.parseInt(args[3])*(-1);//模拟传播延迟_毫秒级
      System.out.println("Server listening port = " + initPort);
      System.out.println("Server passwd = " + passwd);
      System.out.println("Server LOSS_RATE = " + LOSS_RATE);
      System.out.println("Server AVERAGE_DELAY = " + AVERAGE_DELAY);
		while (true)
		{	
			byte[] receiveData = new byte[256];
			byte[] sendData = new byte[256];
			DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
			serverSocket.receive(receivePacket);		//接收到数据
			
		String sentence = new String(receivePacket.getData());
		InetAddress IPAddress = receivePacket.getAddress();
		int port = receivePacket.getPort();
         String recvdata = printData(receivePacket);
			boolean retVal = recvdata.endsWith(passwd);
         if(!retVal){
            System.out.println("  Reply not sent. Password error.\n");
            continue;
         }
			long randomTime = (long) (Math.random()*1500);//生成随机数，用于模拟传输延迟
			Thread.sleep(randomTime);			//程度睡眠，用于模拟传输延迟
			if (randomTime > 1000)				//如果随机数大于1000，模拟数据循丢失
			{	
				String[] s=sentence.split("\n");
				sentence = s[0]+"\n"+"lost \n";	
			}			
			System.out.println(sentence);
			//sendData = sentence.getBytes();			请求数据转换成byte数组，用于发回client端 				
			byte[] buf = recvdata.replaceFirst("PING", "PINGECHO").getBytes();//将发送过来的数据包前缀进行替换作为回复数据包的内容
         DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, port);
			serverSocket.send(sendPacket);

		}
	}
   private static String printData(DatagramPacket request) 
         throws Exception
         {
        //获取对数据包字节数组的引用
         byte[] buf = request.getData();

         //将字节包装到字节数组输入流中，以便以字节流的形式读取数据
         ByteArrayInputStream bais 
           = new ByteArrayInputStream(buf);

         //流读取器
         InputStreamReader isr 
           = new InputStreamReader(bais);

         //将输入流读取器包装在buffered读取器中，以便一次读取一行字符数据
         //一行（由\r和\n的任意组合终止的字符序列）
         BufferedReader br 
           = new BufferedReader(isr);

         //消息包括在一行中，所以读这行
         String line = br.readLine();

         String data = new String(line);
         //打印主机地址和从它那里接收到的数据
         System.out.println("Received from " +         
            request.getAddress().getHostAddress() +
            ": " +
            data);

         return data;
   }//打印结束
	
}