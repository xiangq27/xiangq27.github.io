//PingClient.java
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.text.*;
public class PingClient
{
    public static void main(String[] args) throws Exception
    {
        String ip = args[0];
        int port = new Integer(args[1]);
        int passwd = new Integer(args[2]);
        Long[]rtt = new Long[10];
        System.out.println("host: " + ip);
        System.out.println("port: " + port);
        System.out.println("passwd: " + passwd + "\n");
        DatagramSocket clientSocket = new DatagramSocket();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
        InetAddress IPAdress = InetAddress.getByName(ip);
        for (int i=1; i<=10; i++)
        {
            System.out.println("PING"+i);
            byte[] sendData = new byte[256];
            byte[] receiveData = new byte[256];
            String message = "PingUDP Number:"+ i + " " + format.format(new Date()) +" "+ passwd+ "\n\r";
            sendData = message.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length,IPAdress,port);
            Date sendBfore = new Date();
            clientSocket.send(sendPacket);
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            Date sendAfter = new Date();
            clientSocket.receive(receivePacket);
            String receivemessage = new String(receivePacket.getData());
            rtt[i-1] = sendAfter.getTime() - sendBfore.getTime();
            System.out.println("RTT:" + rtt[i-1]);
            System.out.println(receivemessage);
        }
        long sumrtt = 0;
        long maxrtt = 0;
        long minrtt = rtt[0];
        for (int i=0;i<10;i++)
        {
            if (rtt[i] > maxrtt)
            {
                maxrtt = rtt[i];
            }
            if (rtt[i] < minrtt)
            {
                minrtt = rtt[i];
            }
            sumrtt += rtt[i];
        }
        System.out.println("MAXRtt" + maxrtt);
        System.out.println("MINRtt" + minrtt);
        System.out.println("AverageRtt" + sumrtt /10 + "ms");
    }
}
