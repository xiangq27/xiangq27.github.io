// PingServer.java
    import java.io.*;
    import java.io.IOException;
    import java.math.BigInteger;
    import java.text.SimpleDateFormat;
    import java.time.Instant;
    import java.util.Date;
    import java.net.*;
    import java.util.*;

    /* 
     * Server to process ping requests over UDP.
     */
        
    public class PingServer
    {
       private static final double LOSS_RATE = 0.3;
       private static final int AVERAGE_DELAY = 100; // milliseconds

       public static void main(String[] args) throws Exception
       {
          // Get command line argument.
          if (args.length == 0) {
             System.out.println("Required arguments: port");

             return;
          }
          if (args.length == 1) {
             System.out.println("Required arguments: passwd");

             return;
          }


          int port = Integer.parseInt(args[0]);
          String passwd = args[1];


          // Create random number generator for use in simulating
          // packet loss and network delay.
          Random random = new Random();

          // Create a datagram socket for receiving and sending
          // UDP packets through the port specified on the
          // command line.
          DatagramSocket socket = new DatagramSocket(port);
/*

           // 创建接收端Socket对象
        // DatagramSocket(int port)
        DatagramSocket ds = new DatagramSocket(10086);
        // 创建一个数据包(接收容器)
        // DatagramPacket(byte[] buf, int length)
        byte[] bys = new byte[1024];
        int length = bys.length;
        DatagramPacket dp = new DatagramPacket(bys, length);
        // 调用Socket对象的接收方法接收数据
        ds.receive(dp);// 阻塞式
        // 解析数据包，并显示在控制台
        // 获取对方的ip
        // public InetAddress getAddress()
        InetAddress address = dp.getAddress();
        String ip = address.getHostAddress();
        // public byte[] getData():获取数据缓冲区
        // public int getLength():获取数据的实际长度
        byte[] bys2 = dp.getData();
        int len = dp.getLength();
        String s = new String(bys2, 0, len);
        if(s.equals(passwd)==false){
          DatagramPacket request = new DatagramPacket(new byte[1024], 1024);
          InetAddress clientHost = request.getAddress();
          int clientPort = request.getPort();
          // DatagramSocket()
            DatagramSocket ds1 = new DatagramSocket();
            // 创建数据，并把数据打包
            // DatagramPacket(byte[] buf, int length, InetAddress address, int port)
           // 创建数据
            byte[] bys1 = "Wrong Passwd".getBytes();
            // 长度
            int len1 = bys1.length;
            // IP地址对象
            DatagramPacket dp1 = new DatagramPacket(bys,len1,clientHost,10087);
            // 调用Socket对象的发送方法发送数据包
            // public void send(DatagramPacket p)
            socket.send(dp1);
            // 释放资源
            ds.close();
        }
        else{
          DatagramPacket request = new DatagramPacket(new byte[1024], 1024);
          InetAddress clientHost = request.getAddress();
          int clientPort = request.getPort();
          // DatagramSocket()
            DatagramSocket ds2 = new DatagramSocket();
            // 创建数据，并把数据打包
            // DatagramPacket(byte[] buf, int length, InetAddress address, int port)
           // 创建数据
            byte[] bys3 = "Welcome Connect".getBytes();
            // 长度
            int len2 = bys3.length;
            // IP地址对象
            DatagramPacket dp2 = new DatagramPacket(bys2,len2,clientHost,clientPort);
            // 调用Socket对象的发送方法发送数据包
            // public void send(DatagramPacket p)
            socket.send(dp2);
            // 释放资源
        }*/



         while(true) {
       DatagramPacket
                request1 = new DatagramPacket(new byte[1024], 1024);
      
             // Block until receives a UDP packet.
             socket.receive(request1);
         
             // Print the received data, for debugging
             printData(request1);
             // public int getLength():获取数据的实际长度
             byte[] bys2 = request1.getData();
             int len = request1.getLength();
             String s = new String(bys2, 0, len);
        
             // Decide whether to reply, or simulate packet loss.
            // if (random.nextDouble() < LOSS_RATE) {
              //  System.out.println(" Reply not sent.");
            // }

             // Simulate prorogation delay.
             //Thread.sleep((int) (random.nextDouble() * 2 * AVERAGE_DELAY));

             String response;
             byte[] bys3;
             if(s.equals(passwd)==false){
                response="wrong";
                bys3 = "Wrong passwd".getBytes();
             }
             else {
                response = "correct";
                bys3 = "Welcome Connect".getBytes();
             }

             // Send reply.
             InetAddress clientHost = request1.getAddress();
             int clientPort = request1.getPort();

             DatagramPacket
             reply1 = new DatagramPacket(bys3, bys3.length, 
                                        clientHost, clientPort);
        
             socket.send(reply1);
        
             System.out.println(response);
             if(response.equals("wrong")){
               continue;}



         for (int i=0;i<10;i++) {
   

           // Check Time by taoabo
           URL url = new URL("http://www.taobao.com");
               URLConnection conn = url.openConnection();
               conn.connect();
               long dateL = conn.getDate();
               Date date = new Date(dateL);
               SimpleDateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");

               String TimeStamp = dateFormat.format(date);
               String payLoad = "\nPingUDP " + i + " " + TimeStamp;
               System.out.println(payLoad);
               // Create a datagram packet to hold incomming UDP packet.
             DatagramPacket
                request = new DatagramPacket(new byte[1024], 1024);
      
             // Block until receives a UDP packet.
             socket.receive(request);
         
             // Print the received data, for debugging
             printData(request);

             // Decide whether to reply, or simulate packet loss.
             if (random.nextDouble() < LOSS_RATE) {
                System.out.println(" Reply not sent.");
                continue;
             }

             // Simulate prorogation delay.
             Thread.sleep((int) (random.nextDouble() * 2 * AVERAGE_DELAY));

             // Send reply.
             InetAddress clientHost1 = request.getAddress();
             int clientPort1 = request.getPort();
             
             byte[] buf = request.getData();
             DatagramPacket
             reply = new DatagramPacket(buf, buf.length, 
                                        clientHost1, clientPort1);
        
             socket.send(reply);
        
             System.out.println(" Reply sent.");
         } // end of for
       }//end of while
       } // end of main

       /* 
        * Print ping data to the standard output stream.
        */
       private static void printData(DatagramPacket request) 
               throws Exception

       {
          // Obtain references to the packet's array of bytes.
          byte[] buf = request.getData();

          // Wrap the bytes in a byte array input stream,
          // so that you can read the data as a stream of bytes.
          ByteArrayInputStream bais 
              = new ByteArrayInputStream(buf);

          // Wrap the byte array output stream in an input 
          // stream reader, so you can read the data as a
          // stream of **characters**: reader/writer handles 
          // characters
          InputStreamReader isr 
              = new InputStreamReader(bais);

          // Wrap the input stream reader in a bufferred reader,
          // so you can read the character data a line at a time.
          // (A line is a sequence of chars terminated by any 
          // combination of \r and \n.)
          BufferedReader br 
              = new BufferedReader(isr);

          // The message data is contained in a single line, 
          // so read this line.
          String line = br.readLine();

          // Print host address and data received from it.
          System.out.println("Received from " +         
            request.getAddress().getHostAddress() +
            ": " +
            new String(line) );
         } // end of printData
       } // end of class
    
