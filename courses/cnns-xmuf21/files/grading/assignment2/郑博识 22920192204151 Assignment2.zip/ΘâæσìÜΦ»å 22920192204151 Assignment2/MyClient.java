import java.io.IOException;
import java.math.BigInteger;
import java.net.*;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;



public class MyClient{
    private static final double LOSS_RATE=0.3;
    private static final int AVERAGE_DELAY = 100; // milliseconds
    public static void main(String[] args) throws IOException {
        ////参数个数为2:需要指定服务器的IP及端口
        if(args.length == 0){
            System.out.println("Required arguments: host port");
            return;
        }
        if(args.length == 1){
            System.out.println("Required arguments: port");
            return;
        }
        if(args.length == 2){
          System.out.println("Required arguments: passwd");
          return;
        }

        DatagramSocket clientSocket = new DatagramSocket(); // 发起对服务器的链接
        clientSocket.setSoTimeout(1000); // 等待一秒

        

        // 接收IP地址及端口
        String ipAddress = args[0];
        int port = Integer.parseInt(args[1]);
        String passwd = args[2];

        System.out.println(ipAddress + " " + port);
        InetAddress Ip = InetAddress.getByName(ipAddress);
        clientSocket.connect(Ip, port); // build connection

        /*
          // DatagramSocket()
          DatagramSocket ds = new DatagramSocket();
          // 创建数据，并把数据打包
          // DatagramPacket(byte[] buf, int length, InetAddress address, int port)
         // 创建数据
          byte[] bys = passwd.getBytes();
          // 长度
          int len = bys.length;
          // IP地址对象
          DatagramPacket dp = new DatagramPacket(bys,len,Ip,10086);
          // 调用Socket对象的发送方法发送数据包
          // public void send(DatagramPacket p)
          ds.send(dp);
          // 释放资源
          ds.close();
         
          DatagramSocket ds1 = new DatagramSocket(10087);
            DatagramPacket dp1 = new DatagramPacket(bys, bys.length);
            // 接收数据
            ds.receive(dp1);
            // 解析数据
            String ip = dp1.getAddress().getHostAddress();
            String s = new String(dp.getData(), 0, dp1.getLength());
            System.out.println(s);
            if(s.equals("Wrong Passwd")==true){
              return;
            }
        // 释放资源
        // 接收端应该一直开着等待接收数据，是不需要关闭
         ds.close();
*/         
        
        byte[] sendData1 = new byte[1024];
        byte[] receiveData1 = new byte[1024];
        sendData1 = passwd.getBytes();
        DatagramPacket packet1 = new DatagramPacket(sendData1, sendData1.length);
        clientSocket.send(packet1);
        packet1 = new DatagramPacket(receiveData1, receiveData1.length);
        clientSocket.receive(packet1); // receive packet
        String reply1 = new String(packet1.getData(), packet1.getOffset(), packet1.getLength());
        System.out.println(reply1);
        //clientSocket.close();      
        if(reply1.equals("Wrong passwd")){
          System.exit(1);}

        
        long CurrentTime = 0; // caculate the time
        long RTT = 0;
        int count = 10;
        double RTT_average = 0.0;
        long RTT_maximum = 0, RTT_minimum = 999999999;
        DatagramSocket dataSocket = new DatagramSocket();
      
        for(int i = 0; i < 10; i++) {
            CurrentTime = 0;
            byte[] sendData = new byte[1024];
            byte[] receiveData = new byte[1024];

            // Check time by taobao
              URL url = new URL("http://www.taobao.com");
              URLConnection conn = url.openConnection();
              conn.connect();
              long dateL = conn.getDate();
              Date date = new Date(dateL);
              SimpleDateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
           //   return dateFormat.format(date);
          //} catch (MalformedURLException e) {
            //  e.printStackTrace();
         // } catch (IOException e) {
           //   e.printStackTrace();
         // }

           // Date date = new Date();
           // SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String TimeStamp = dateFormat.format(date);
            String payLoad = "\nPingUDP " + i + " " + TimeStamp;
            System.out.println(payLoad);

            sendData = payLoad.getBytes();
            DatagramPacket packet = new DatagramPacket(sendData, sendData.length);
            clientSocket.send(packet);
            CurrentTime = System.currentTimeMillis();
            try {
                packet = new DatagramPacket(receiveData, receiveData.length);
                clientSocket.receive(packet); // receive packet
                RTT = System.currentTimeMillis() - CurrentTime;
                String reply = new String(packet.getData(), packet.getOffset(), packet.getLength());
                System.out.println("Receive: " + reply + "\nRTT is " + RTT + " ms.");
                RTT_average += RTT;
                RTT_maximum = Math.max(RTT_maximum, RTT);
                RTT_minimum = Math.min(RTT_minimum, RTT);
            } catch (java.net.SocketTimeoutException e) {
                String reply = "No Reply!";
                count--;
                System.out.println(reply);
                continue;
            }
        }//end of for
        System.out.println("\nsend " + count + " packets successfully "+
                "\nRTT_average:" + RTT_average/(count * 1.0) +
                " ms.\nRTT_maximum:" + RTT_maximum +
                " ms.\nRTT_minimum:" + RTT_minimum + " ms.");

        clientSocket.close();

    }//end of main

}//end of class

