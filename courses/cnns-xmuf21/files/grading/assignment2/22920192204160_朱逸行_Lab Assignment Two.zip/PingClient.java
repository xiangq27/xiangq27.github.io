import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class PingClient
{
    public static int port;
    public static String passwd;
    public static InetAddress address;
    public static int i;
    public static long[] rtt = new long[10];
    public static Timer t1 =  new Timer();

    public static void main(String[] args) throws Exception
    {
        // Get command line argument.
        //java PingServer port passwd [-delay delay] [-loss loss]
        if (args.length!=3) {
            System.out.println("Format Error");
            return;
        }
        String host = args[0];
        port = Integer.parseInt(args[1]);
        passwd = args[2];
        address = InetAddress.getByName(host);
        t1.schedule(new myTask(),0,1000);
    } // end of main

    public static class myTask extends TimerTask{
        public void run(){
            i++;
            String sequence_number;
            if(i<10)
            {
                sequence_number = "0" + String.valueOf(i);
            }
            else
            {
                sequence_number = String.valueOf(i);
            }
            long star =System.currentTimeMillis();
            SimpleDateFormat dateformat = new SimpleDateFormat("yyyyMMdd");
            String client_send_time = dateformat.format(star);
            String send_message = "PING " + sequence_number + " " + client_send_time + " " + passwd;
            byte[] data = send_message.getBytes();
            //DatagramPacket packs data
            DatagramPacket request = new DatagramPacket(data,data.length,address,port);
            //DatagramSocket is used to send and receive data
            try
            {
                DatagramSocket socket = new DatagramSocket();
                //send
                socket.send(request);
                //set time limit
                socket.setSoTimeout(1000);
                DatagramPacket reply = new DatagramPacket(new byte[1024], 1024);
                socket.receive(reply);
                //end time
                long end = System.currentTimeMillis();
                printData(reply);
                rtt[i-1]=end-star;
                System.out.println("RTT:" + rtt[i-1] + "ms");
                System.out.println("            Reply Received.\n");
                socket.close();
            } catch (Exception e){
                System.out.println("            Time out.\n");
                rtt[i-1]=999999;
            }
            if(i==10) {
                t1.cancel();
                long min1 = 999999, max1 = 0, sum = 0;
                int j = 10, m;
                for (m = 0; m < 10; m++) {
                    if (rtt[m] == 999999) continue;
                    if (rtt[m] < min1) min1 = rtt[m];
                    if (rtt[m] > max1) max1 = rtt[m];
                    sum = sum + rtt[m];
                    j--;
                }
                double aver = (double) sum / (double) (10 - j);
                System.out.print("mininum:" + min1 + " maximum:" + max1 + " average:" + aver + "\nloss rate:");
                if (j == 10) {
                    System.out.println("1.0");
                } else if (j == 0) {
                    System.out.println("0");
                } else {
                    System.out.println("0." + j);
                }
            }
        }
    }

    private static void printData(DatagramPacket request)
            throws Exception
    {
        // Obtain references to the packet's array of bytes.
        byte[] buf = request.getData();
        // Wrap the bytes in a byte array input stream,
        // so that you can read the data as a stream of bytes.
        ByteArrayInputStream bais = new ByteArrayInputStream(buf);
        // Wrap the byte array output stream in an input
        // stream reader, so you can read the data as a
        // stream of **characters**: reader/writer handles
        // characters
        InputStreamReader isr = new InputStreamReader(bais);
        // Wrap the input stream reader in a bufferred reader,
        // so you can read the character data a line at a time.
        // (A line is a sequence of chars terminated by any
        // combination of \r and \n.)
        BufferedReader br = new BufferedReader(isr);
        // The message data is contained in a single line,
        // so read this line.
        String line = br.readLine();
        //PINGECHO sequence_number client_send_time passwd CRLF
        // Print host address and data received from it.
        System.out.println("Received from Server " + request.getAddress().getHostAddress() + ": " + new String(line) );
    } // end of printData
} // end of class