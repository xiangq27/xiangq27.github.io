import java.io.*;
import java.net.*;
import java.util.*;
import java.text.*;

public class PingServer
{
    //private static final double LOSS_RATE = 0.3;
    //private static final int AVERAGE_DELAY = 100;
    public static void main(String[] args) throws Exception
    {
        // Get command line argument.
        if (args.length < 2 || args.length > 6) {
            System.out.println("Format Error");
            return;
        }
        int port = Integer.parseInt(args[0]);
        if (port <= 1024) {
            System.out.println("Port should be greater than 1024");
            return;
        }
        String pass = args[1];
        String choice1 = "-dalay";
        String choice2 = "-loss";
        int AVERAGE_DELAY = 0;
        double LOSS_RATE = 0.2;
        if(args.length>=3)
        {
            if(args[2].equals(choice1))
            {
                AVERAGE_DELAY = Integer.parseInt(args[3]);
            }
            else if(args[2].equals(choice2))
            {
                LOSS_RATE = Integer.parseInt(args[3]);
            }
            if(args.length>=5)
            {
                if(args[4].equals(choice1))
                {
                    AVERAGE_DELAY = Integer.parseInt(args[5]);
                }
                else if(args[4].equals(choice2))
                {
                    LOSS_RATE = Double.parseDouble(args[5]);
                }
            }
        }
        // Create random number generator for use in simulating
        // packet loss and network delay.
        Random random = new Random();
        // Create a datagram socket for receiving and sending
        // UDP packets through the port specified on the
        // command line.
        DatagramSocket socket = new DatagramSocket(port);

        // Processing loop.
        int i=0;
        while (true) {
            i++;
            // Create a datagram packet to hold incomming UDP packet.
            DatagramPacket request = new DatagramPacket(new byte[1024], 1024);
            // Block until receives a UDP packet.
            socket.receive(request);
            // Print the received data, for debugging
            int x=printData(request,pass);
            // Decide whether to reply, or simulate packet loss.
            if (random.nextDouble() < LOSS_RATE) {
                System.out.println("        Reply not sent.");
                continue;
            }
            // Simulate prorogation delay.
            Thread.sleep((int) (random.nextDouble() * 2 * AVERAGE_DELAY));
            // Send reply.
            InetAddress clientHost = request.getAddress();
            int clientPort = request.getPort();
            if(x==0)//password wrong
            {
                String reply_message = "Your password is wrong.";
                byte[] data=reply_message.getBytes();
                DatagramPacket reply = new DatagramPacket(data, data.length,clientHost, clientPort);
                socket.send(reply);
                System.out.println("        Wrong password reply sent.");
                continue;
            }
            SimpleDateFormat dateformat = new SimpleDateFormat("yyyyMMdd");
            String client_send_time = dateformat.format(System.currentTimeMillis());
            String reply_message = "PINGECHO " + i + " " + client_send_time + " " + pass;
            byte[] data=reply_message.getBytes();
            DatagramPacket reply = new DatagramPacket(data, data.length, clientHost, clientPort);
            socket.send(reply);
            System.out.println("        Reply sent.");
        } // end of while
    } // end of main
    private static int printData(DatagramPacket request,String pass)
            throws Exception
    {
        byte[] buf = request.getData();
        ByteArrayInputStream bais = new ByteArrayInputStream(buf);
        InputStreamReader isr = new InputStreamReader(bais);
        BufferedReader br = new BufferedReader(isr);
        String line = br.readLine();
        //password compare
        int count1=0,st=0,k,en=0;
        for(k=0;k<line.length();k++)
        {
            if(line.charAt(k)==' ')
            {
                count1++;
            }
            if(count1==3)
            {
                st=k+1;
                count1++;
            }
            if(line.charAt(k)=='\0')
            {
                en=k;
                break;
            }
        }
        String passwd = line.substring(st,en);
        if(pass.compareTo(passwd)!=0)
        {
            System.out.println("Wrong password.  " + "Correct passwd:|"+pass+"|  Received passwd:|"+passwd+"|");
            System.out.println("Received from Client " + request.getAddress().getHostAddress() + ": " + new String(line) );
            return 0;
        }
        System.out.println("Received from Client " + request.getAddress().getHostAddress() + ": " + new String(line) );
        return 1;
    } // end of printData
} // end of class