/**
 * @Author: WangYao
 * @Date: 2021/10/7
 * @Version 1.0
 */

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.util.Random;

public class PingServer {
    // 主要参数
    private static double LOSS_RATE = 0.3;
    private static int AVERAGE_DELAY = 100; // milliseconds
    private static final String CRLF = "\r\n";
    private static final String pingEcho = "PINGECHO";

    public static void main(String[] args) throws Exception {
        if (args.length < 2) {
            System.out.println("Required arguments: port & password");
            return;
        }
        // 端口、合法密码、[丢包率]、[平均延时]
        int port = Integer.parseInt(args[0]);
        String validPassword = args[1];
        if (args.length > 2) {
            for (int i = 2; i < args.length; i++) {
                if (args[i].equals("-delay")) {
                    AVERAGE_DELAY = Integer.parseInt(args[i + 1]);
                    i++;
                } else if (args[i].equals("-loss")) {
                    LOSS_RATE = Double.parseDouble(args[i + 1]);
                    i++;
                } else {
                    System.out.println("Syntax Error");
                    return;
                }
            }
        }
        // 信息输出
        System.out.println("Server start... port: " + port + " & password: " + validPassword);

        Random random = new Random();
        // 建立socket
        DatagramSocket socket = new DatagramSocket(port);
        // 响应报文长度
        int resLen = pingEcho.length() + Short.SIZE / Byte.SIZE + Long.SIZE / Byte.SIZE + validPassword.length() + CRLF.length();
        // 请求报文长度，密码长度按 validPassword.length() + CRLF.length()截去，请求密码过长也是错，不影响正误判断
        int reqLen = resLen - 4;
        // Processing loop.
        while (true) {
            byte[] data = new byte[1024];
            // 接收请求报文
            DatagramPacket request = new DatagramPacket(data, data.length);
            socket.receive(request);

            // Decide whether to reply, or simulate packet loss.
            if (random.nextDouble() < LOSS_RATE) {
                System.out.println(" Reply not sent.");
                continue;
            }

            System.out.println("来自 " + request.getAddress().getHostAddress() + " 的请求：");
            // 将数据写入内存
            ByteBuffer reqBuffer = ByteBuffer.allocate(reqLen);
            reqBuffer.put(request.getData(), 0, reqLen);
            reqBuffer.flip();
            // 读出数据
            byte[] ping = new byte[4];
            byte[] password = new byte[reqLen - 14];
            reqBuffer.get(ping, 0, ping.length);
            short sequence_number = reqBuffer.getShort();
            long client_send_time = reqBuffer.getLong();
            reqBuffer.get(password, 0, password.length);
            // 判断密码是否合法
            if ((validPassword + CRLF).equals(new String(password))) {
                System.out.println(new String(ping) + " " + sequence_number + " " + client_send_time +
                        " " + new String(password).trim());
            } else {
                System.out.println("密码无效。");
                continue;
            }

            // Simulate prorogation delay.
            Thread.sleep((int) (random.nextDouble() * 2 * AVERAGE_DELAY));

            

            // 将响应数据写入内存作为直接数组
            ByteBuffer resBuffer = ByteBuffer.allocate(resLen);
            resBuffer.put(pingEcho.getBytes());
            resBuffer.putShort(sequence_number);
            resBuffer.putLong(client_send_time);
            resBuffer.put((validPassword + CRLF).getBytes());
            resBuffer.flip();

            // 将内存数据转为响应报文，并发送给客户端
            InetAddress clientHost = request.getAddress();
            int clientPort = request.getPort();
            DatagramPacket response = new DatagramPacket(resBuffer.array(), resLen, clientHost, clientPort);
            socket.send(response);
            System.out.println("Reply sent.");
        }
    }
}
