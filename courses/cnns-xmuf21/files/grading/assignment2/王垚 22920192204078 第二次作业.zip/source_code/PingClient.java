/**
 * @Author: WangYao
 * @Date: 2021/10/7
 * @Version 1.0
 */

import java.io.IOException;
import java.nio.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.CountDownLatch;

public class PingClient {
    private static final String CRLF = "\r\n";
    // 主要参数
    private static final int request_times = 10;          // 请求次数
    private static long minimum = 2000;                   // 最大延时
    private static long maximum = 0;                      // 最小延时
    private static long total_time = 0;                   // 总往返行程耗时
    private static int counter = 0;                       // 收包次数
    private static short sequence_number = 0;
    private static String ping = "PING";

    public static void main(String[] args) throws Exception {
        // 判断是否有三个参数
        if (args.length != 3) {
            System.out.println("Required arguments: host & port & password");
            return;
        }
        // 主机、端口、密码
        InetAddress host = InetAddress.getByName(args[0]);
        int port = Integer.parseInt(args[1]);
        String password = args[2];
        // 请求报文长度
        int reqLen = ping.length() + Short.SIZE / Byte.SIZE + Long.SIZE / Byte.SIZE + password.length() + CRLF.length();
        // 建立socket，最大延迟1s
        DatagramSocket socket = new DatagramSocket();
        socket.setSoTimeout(1000);

        

        System.out.println("正在 Ping " + args[0] + ":" + args[1] + " 具有 " + reqLen + " 字节的数据:");
        // 用CountDownLatch让主线程等待子线程
        final CountDownLatch latch = new CountDownLatch(request_times);
        // 定时器，每隔一秒触发一个线程（发送一个请求）
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                sequence_number++;
                if (sequence_number >= request_times) {
                    // 达到请求次数，中断定时器
                    timer.cancel();
                }

                long client_send_time = System.currentTimeMillis();
                // 将需要发送的信息写入内存，转为byte数组
                ByteBuffer reqBuffer = ByteBuffer.allocate(reqLen);
                reqBuffer.put(ping.getBytes());
                reqBuffer.putShort(sequence_number);
                reqBuffer.putLong(client_send_time);
                reqBuffer.put((password + CRLF).getBytes());
                reqBuffer.flip();

                // 从reqBuffer中获得字节数组，生成报文
                DatagramPacket request = new DatagramPacket(reqBuffer.array(), reqLen, host, port);

                // 判断是否发送成功
                boolean flag = true;
                // 计时开始
                long clock_start = System.currentTimeMillis();
                //发送报文
                try {
                    socket.send(request);
                } catch (IOException e) {
                    flag = false;
                    e.printStackTrace();
                }
                if (flag) {
                    // 发送成功后，准备接收返回报文
                    byte[] data = new byte[1024];
                    DatagramPacket response = new DatagramPacket(data, data.length);
                    // 应答报文长度
                    int resLen = reqLen + 4;
                    try {
                        socket.receive(response);
                        // 计时结束
                        long clock_end = System.currentTimeMillis();
                        // 将应答报文写入内存
                        ByteBuffer resBuffer = ByteBuffer.allocate(resLen);
                        resBuffer.put(response.getData(), 0, resLen);
                        resBuffer.flip();
                        // 逐个读出报文内容
                        byte[] pingEcho = new byte[8];
                        byte[] passwordEcho = new byte[resLen - 18];
                        resBuffer.get(pingEcho, 0, pingEcho.length);
                        short seqEcho = resBuffer.getShort();
                        long timeEcho = resBuffer.getLong();
                        resBuffer.get(passwordEcho, 0, passwordEcho.length);
                        // 计算收包次数、本次延时、总延时、最大延时、最小延时
                        counter++;
                        long time = clock_end - clock_start;
                        total_time += time;
                        if (time > maximum) {
                            maximum = time;
                        } else if (time < minimum) {
                            minimum = time;
                        }
                        // 输出
                        System.out.println("来自 " + host.getHostAddress() + " 的回复：" + new String(pingEcho) + " " +
                                seqEcho + " " + timeEcho + " " + new String(passwordEcho).trim() + " 时间=" +
                                time + "ms");
                    } catch (IOException e) {
                        // 为接收到返回报文
                        System.out.println("请求超时。");
                    }
                } else {
                    // 发送报文失败
                    System.out.println("请求失败。");
                }
                latch.countDown();
            }
        }, 1000, 1000);
        // 等待子线程结束
        latch.await();

        showStatistics(host);
    }

    public static void showStatistics(InetAddress host) {
        // 输出统计结果
        System.out.println("\r\n" + host.getHostAddress() + " 的 Ping 统计信息：");
        System.out.printf("\t数据包：已发送 = %d，已接收 = %d，丢失 = %d (%.2f%%丢失)\r\n", sequence_number,
                counter, sequence_number - counter, 100.0 * (sequence_number - counter) / sequence_number);
        // 若有收包，统计结果并输出
        if (counter > 0) {
            System.out.println("往返行程的估计时间(以毫秒为单位):");
            System.out.printf("\t最短 = %dms，最长 = %dms，平均 = %dms\r\n", minimum, maximum, total_time / counter);
        }
    }
}
