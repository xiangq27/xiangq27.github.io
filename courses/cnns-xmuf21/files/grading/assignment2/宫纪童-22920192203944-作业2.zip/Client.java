//借鉴https://blog.csdn.net/qq_23473123/article/details/51464272
// JAVA Socket 实现 UDP 编程
    import java.io.*;
    import java.net.*;
    import java.util.*;
/*
 * 客户端
 */
public class Client{
         public static void main(String[] args) throws IOException {
        /*
         * 向服务器端发送数据
         */
        // 1.定义服务器的地址、端口号、数据
        int i=1;
        Double count=0.0;
        long min=100;
        long max=0;
        long sum=0;
        long send=0;
        long rece=0;
        long temp=0;
        int port;
        port = Integer.parseInt(args[1]);
        InetAddress address = InetAddress.getByName(args[0]);
        while(i<11) {
            send=System.currentTimeMillis();
            String request = "PING " + i +" "+ send+" " + args[2];
            byte[] data = request.getBytes();
            // 2.创建数据报，包含发送的数据信息
            DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
            // 3.创建DatagramSocket对象
            DatagramSocket socket = new DatagramSocket();
            // 4.向服务器端发送数据报
            socket.send(packet);
            i++;
            /*
             * 接收服务器端响应的数据
             */
            // 1.创建数据报，用于接收服务器端响应的数据
            byte[] data2 = new byte[1024];
            DatagramPacket packet2 = new DatagramPacket(data2, data2.length);
            // 2.接收服务器响应的数据
            socket.setSoTimeout(1000);
                try{
                    socket.receive(packet2);
                    rece=System.currentTimeMillis();
                }catch (SocketTimeoutException e){
                    continue;
                }
            count= count+1;
            temp=rece-send;
            // 3.读取数据
            if(temp<min){
                min=temp;
            }
            if(temp>max){
                max=temp;
            }
            sum = sum + temp;
            String reply = new String(data2, 0, packet2.getLength());
            System.out.println(reply);

        }
        System.out.println("***report***");
        System.out.println("min: "+ min +"ms " + "max: " + max +"ms " + "average: "+sum/count+"ms" );
        Double rate = count / 10;
        System.out.println("loss:"+ String.valueOf((1-rate)*100) +"%");
    }
}


