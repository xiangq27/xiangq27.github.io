//借鉴https://blog.csdn.net/qq_23473123/article/details/51464272
// JAVA Socket 实现 UDP 编程

import java.io.*;
import java.net.*;
import java.util.*;

/*
 * 服务器端，实现基于UDP的用户登陆
 */
public class Server{

    private static double LOSS_RATE = 0.3;
    private static int AVERAGE_DELAY = 100; // milliseconds
    public static void main(String[] args) throws Exception {

        /*
         * 接收客户端发送的数据
         */
        LOSS_RATE = Double.parseDouble(args[2]);
        AVERAGE_DELAY = Integer.parseInt(args[3]);
        int i = 0;
        // 1.创建服务器端DatagramSocket，指定端口
        int port;
        port = Integer.parseInt(args[0]);
        String passwd = args[1];
        DatagramSocket socket = new DatagramSocket(port);
        byte[] data = new byte[1024];// 创建字节数组，指定接收的数据包的大小
        DatagramPacket packet = new DatagramPacket(data, data.length);
        // 3.接收客户端发送的数据
        System.out.println("**服务器端已经启动: " + InetAddress.getLocalHost());
        System.out.println("**passwd: " + args[1]);
        while (i < 11) {
            // 2.创建数据报，用于接收客户端发送的数据

            socket.receive(packet);// 此方法在接收到数据报之前会一直阻塞
            i++;
            // 4.读取数据
            String info = new String(data, 0, packet.getLength());
            System.out.println(info);
            /*
             * 向客户端响应数据
             */
            Random random = new Random();
            if (random.nextDouble() < LOSS_RATE) {
                System.out.println(" Reply not sent.");
                continue;
            }
            // Simulate prorogation delay.
            Thread.sleep((int) (random.nextDouble() * 2 * AVERAGE_DELAY));

            // 1.定义客户端的地址、端口号、数据
            InetAddress address = packet.getAddress();
            int portc = packet.getPort();
            String reply = "PINGCHO " + i + " " + System.currentTimeMillis() + " " + passwd;
            byte[] data2 = reply.getBytes();
            // 2.创建数据报，包含响应的数据信息
            DatagramPacket packet2 = new DatagramPacket(data2, data2.length, address, portc);
            // 3.响应客户端
            socket.send(packet2);
        }
    }
}
