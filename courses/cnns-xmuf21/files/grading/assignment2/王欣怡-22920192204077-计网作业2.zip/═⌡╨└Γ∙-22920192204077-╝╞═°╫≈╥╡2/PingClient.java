import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PingClient extends Thread{
	//客户端socket
	private DatagramSocket client;
	//服务器的IP地址
	private InetAddress hostAddress;
	//服务器的应用进程端口号
	private int port;
	//定义并初始化接收到的响应报文的个数
	private int replyNum=0;
	//定义并初始化最小往返时间、最大往返时间、平均往返时间
	private long minRtt=0, maxRtt=0, averRtt=0,sumRtt=0;
	//每一个请求对应的rtt，默认初始化为0
	private long[] rtt=new long[10];
	//定义丢包数，丢包率
	private int losenum=0,loserate=0;
	//定义密码
	String passwd="123";
	
	public PingClient(String host, int port) {
		//有效端口的范围是0~65535
		if(port<0 || port>65535) {
			System.out.println("Invalid port number!");
			System.exit(0);
		}
		this.port=port;
		try {
			//初始化客户端实例，将该实例绑定到本机默认的IP地址，本机所有可用端口中随机选择的某个端口
			client=new DatagramSocket();
			//根据服务器主机名称确定服务器的IP地址
			hostAddress=InetAddress.getByName(host);
		} catch (SocketException e) {
			e.printStackTrace();
		} catch (UnknownHostException e) {
			System.out.println("Invalid host name!");
			e.printStackTrace();
		}	
	}
	
	public void run() {
		//定义时间戳格式
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-ddhh:mm:ss.SS");	
		System.out.println("Pinging "+hostAddress+":");
		//模拟发送10条请求
		for(int i=0; i<10; i++) {
		rtt[i]=1001;
		}
		for(int i=0; i<10; i++) {
			//发送报文前的时间
			Date sendTime=new Date();
			//请求数据
			String outMessage="Ping "+i+" "+sdf.format(sendTime)+" "+passwd ;		
			//将请求数据放进缓冲区内
			byte[] buffer=outMessage.getBytes();
			//生成发送报文实例
			DatagramPacket sendPacket=new DatagramPacket(buffer,buffer.length,hostAddress,port);
			
			/*************************生成接收报文******************************/
			byte[] buf=new byte[buffer.length];		
			DatagramPacket recievePacket=new DatagramPacket(buf,buf.length);
	
			//接收到的响应信息
			String recieve=null;
			try {
				//发送到服务器端
				client.send(sendPacket);
				//接收响应报文
				client.setSoTimeout(1000);//设置超时时间为1秒
				client.receive(recievePacket);
				recieve=new String(recievePacket.getData());
				//记录接收后的时间
				Date recieveTime=new Date();
				//计算往返时间
				rtt[i]=recieveTime.getTime()-sendTime.getTime();
			} catch (IOException e) {
				e.printStackTrace();
			}
			//如果接收时间大于1000ms，则认为请求丢失或者对请求的回复丢失
			if(rtt[i]>1000) {
				recieve="Response message lost or Request timed out!";
			}else {
				recieve=recieve+"\n"+"rtt:"+rtt[i]+"ms";
			}
			System.out.println(recieve);			
		}
		
		minRtt=rtt[0];
		for(int i=0;i<10;i++) {
			if(rtt[i]>1000){
				losenum++;
				continue;
			}  
			replyNum++;	
			//计算最小往返时间
			if(minRtt>rtt[i]) {
				minRtt=rtt[i];
			}
			//计算最大往返时间
			if(maxRtt<rtt[i]) {
				maxRtt=rtt[i];
			}
			//计算总往返时间
			sumRtt+=rtt[i];
		}
		if(replyNum!=0) {
			//计算平均往返时间和丢包率
			averRtt = sumRtt/replyNum;
			loserate=losenum*10;
			System.out.println("Ping statistics for " + hostAddress + ":");
			//System.out.println("	Packets: Sent=10, Received="+replyNum+", Lost="+losenum);
			//System.out.println("Approximate round trip times in milli-seconds:");
			System.out.println("	minRTT:" + minRtt + "ms, maxRTT:" + maxRtt + "ms, averRTT:" + averRtt + "ms");
			System.out.println("	packetLoss percet:"+loserate+"%");
		}else {
			System.out.println("Failed to send request! Unable to return message!");
		}
		client.close();
	}
	
	public static void main(String[] args) {
		PingClient clientThread = new PingClient(args[0], Integer.valueOf(args[1]));
		//PingClient clientThread = new PingClient("127.0.0.1", 9999);
		clientThread.start();
	}

}
