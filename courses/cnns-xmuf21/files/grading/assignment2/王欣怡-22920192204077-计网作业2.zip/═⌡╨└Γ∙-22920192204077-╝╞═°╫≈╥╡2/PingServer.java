// PingServer.java
import java.io.*;
import java.net.*;
import java.util.*;
import java.text.SimpleDateFormat;

    /* 
     * Server to process ping requests over UDP.
     */
        
    public class PingServer
    {
       private static final double LOSS_RATE = 0.3;
       private static final int AVERAGE_DELAY = 100; //毫秒
       

       public static void main(String[] args) throws Exception
       {
          // 获取命令行参数
          if (args.length != 1) {
             System.out.println("Required arguments: port");
             return;
          }

          int port = Integer.parseInt(args[0]);

          // 创建用于模拟的随机数生成器
          // 丢包和网络延迟
          Random random = new Random();

          // 创建一个用于接收和发送的数据报套接字
          // UDP 数据包通过指定的端口
          // 命令行
          DatagramSocket socket = new DatagramSocket(port);

          //处理循环
          while (true) {

             // 创建一个数据报数据包来保存传入的 UDP 数据包
             DatagramPacket request = new DatagramPacket(new byte[1024], 1024);
      
             //  阻塞直到收到一个 UDP 数据包
             socket.receive(request);
             
             // 打印接收到的数据，用于调试
             printData(request);

             // 决定是回复，还是模拟丢包
             if (random.nextDouble() < LOSS_RATE) {
                System.out.println(" Reply not sent.");
                continue;
             }

             // 模拟 prorogation 延时
             Thread.sleep((int) (random.nextDouble() * 2 * AVERAGE_DELAY));

             // 发送回复
             InetAddress clientHost = request.getAddress();
             int clientPort = request.getPort();
             byte[] buf = request.getData();
             DatagramPacket reply = new DatagramPacket(buf, buf.length, clientHost, clientPort);
        
             socket.send(reply);
        
             System.out.println(" Reply sent.");
         } // end of while
       } // end of main

       /* 
        * Print ping data to the standard output stream.
        */
       private static void printData(DatagramPacket request)  throws Exception
      {
          // 获取对数据包字节数组的引用
          byte[] buf = request.getData();

          // 将字节包装在字节数组输入流中从而将数据作为字节流读取
        
          ByteArrayInputStream bais  = new ByteArrayInputStream(buf);

          // Wrap the byte array output stream in an input 
          // stream reader, so you can read the data as a
          // stream of **characters**: reader/writer handles 
          // characters
          InputStreamReader isr  = new InputStreamReader(bais);

          // Wrap the input stream reader in a bufferred reader,
          // so you can read the character data a line at a time.
          // (A line is a sequence of chars terminated by any 
          // combination of \r and \n.)
          BufferedReader br = new BufferedReader(isr);

          // The message data is contained in a single line, 
          // so read this line.
          String line = br.readLine();
	  String [] arr2= line.split("\\s+");
	  SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-ddhh:mm:ss.SS");
	  Date Time1=new Date();
          // Print host address and data received from it.
          System.out.println("PINGECHO "+arr2[1]+" "+sdf.format(Time1)+" "+arr2[3]);
         } // end of printData
       } // end of class
