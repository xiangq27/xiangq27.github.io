
 
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Date;
import java.text.SimpleDateFormat;
 
public class PingClient {
	
	public static void main(String[] args) throws Exception{
		if(args.length == 0){
			System.out.println("Required arguments:host port");
			return;//如果控制台输入数据为空 则返回。控制台输入数据用空格隔开，存储在args数组里
		}
		
		String host = args[0].toString();//IP address
		int port = Integer.parseInt(args[1]);//port 
		
		DatagramSocket clientSocket = new DatagramSocket();
		clientSocket.setSoTimeout(1000);//设置等待server回答的时间，以ms为单位。如果是0，则无限等待
		
		InetAddress IPAddress = InetAddress.getByName(host);
		
		for(int i = 0;i<10;i++){
			byte[] sendData = new byte[1024];
			byte[] receiveData = new byte[1024];
			Date currentTime = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String timeStamp = sdf.format(currentTime);
			String pingMessage = "Ping" + i + " " + timeStamp + " " +"\r\n";
			sendData = pingMessage.getBytes();
			
			DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length,IPAddress,port);
			try{
				clientSocket.send(sendPacket);
				
				DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
				clientSocket.receive(receivePacket);
				String reply = new String(receivePacket.getData());
				System.out.println("FROM SERVER: "+reply);
			}catch(java.net.SocketTimeoutException e){
				String reply = "No reply : ";
				System.out.println("FROM SERVER: "+reply);
			}
		}
		clientSocket.close();
	}
}
