
 
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Random;
 
public class PingServer {
	private static final double LOSS_RATE = 0.3;
	private static final int AVERAGE_DELAY = 100;
	public static void main(String[] args) throws Exception{
		if(args.length != 1){
			System.out.println("Required arguments:port");
			return;
		}
		
		int port = Integer.parseInt(args[0]);
		
		Random random = new Random();/*创造随机数用来模拟丢包和网络延迟*/
		DatagramSocket socket = new DatagramSocket(port);
		
		while(true){
			DatagramPacket request = new DatagramPacket(new byte[1024], 1024); //创造一个packet以接收收到的udp包
			
			socket.receive(request);
			printData(request);
			
			if(random.nextDouble()<LOSS_RATE){
				System.out.println("Reply not sent");
				continue;
			}
			
			Thread.sleep((int)(random.nextDouble()*2*AVERAGE_DELAY));
			
			//发送对应的pong报文
			InetAddress clientHost = request.getAddress();
			int clientPort = request.getPort();
			byte[] buffer = request.getData();
			DatagramPacket reply = new DatagramPacket(buffer, buffer.length,clientHost,clientPort);
			socket.send(reply);
			
			System.out.println("Reply sent");
		}
	}
	
	private static void printData(DatagramPacket request) throws Exception{
		byte[] buffer = request.getData();
		
		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		
		InputStreamReader isr = new InputStreamReader(bais);
		
		BufferedReader br = new BufferedReader(isr);
		
		String line = br.readLine();
		
		System.out.println("Received from" + request.getAddress().getHostAddress()+":"+new String(line));
		
	}
}
