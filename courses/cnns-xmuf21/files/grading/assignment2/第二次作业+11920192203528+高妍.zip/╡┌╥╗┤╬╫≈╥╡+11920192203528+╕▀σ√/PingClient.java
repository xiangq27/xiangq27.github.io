
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Arrays;

public class PingClient {

    public static void main(String[] args) throws Exception{
        if(args.length == 0){
            System.out.println("Required arguments:host port");
            return;//如果控制台输入数据为空 则返回。控制台输入数据用空格隔开，存储在args数组里
        }

        String host = args[0].toString();//IP address
        int port = Integer.parseInt(args[1]);//port
        String passwd = args[2].toString();

        long minRtt=0,maxRtt=0,avrRtt=0,sumRtt=0,sum=0;
        double rate=0;
        long[] rtt = new long[10];
        for(int j=0;j<10;j++){
            rtt[j]=0;
        }

        DatagramSocket clientSocket = new DatagramSocket();
        clientSocket.setSoTimeout(1000);//设置等待server回答的时间，以ms为单位。如果是0，则无限等待

        InetAddress IPAddress = InetAddress.getByName(host);

        for(int i = 0;i<10;i++){
            byte[] sendData = new byte[1024];
            byte[] receiveData = new byte[1024];
            Date currentTime = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String timeStamp = sdf.format(currentTime);
            String pingMessage = "PING" + i + " " + timeStamp + " " +passwd+" "+"\r\n";
            sendData = pingMessage.getBytes();

            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length,IPAddress,port);
            try{
                clientSocket.send(sendPacket);

                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                clientSocket.receive(receivePacket);
                Date receiveTime = new Date();
                rtt[i]=receiveTime.getTime() - currentTime.getTime();
                //System.out.println(rtt[i]);
                sum=sum+1;
                sumRtt+=rtt[i];
                String reply = new String(receivePacket.getData());
                System.out.println("FROM SERVER: "+reply);
            }catch(java.net.SocketTimeoutException e){
                //Date receiveTime = new Date();
                //rtt[i]=receiveTime.getTime() - currentTime.getTime();
                //sumRtt+=rtt[i];
                String reply = "No reply : ";
                System.out.println("FROM SERVER: "+reply);
            }
        }
        Arrays.sort(rtt);
        int j=0;
        while(rtt[j]==0){
            j++;
        }
        minRtt=rtt[j];
        maxRtt=rtt[9];
        avrRtt=sumRtt/sum;
        rate=sum/10.0;
        System.out.println("total:10,received:"+sum);
        System.out.println("minRtt:"+minRtt+"ms");
        System.out.println("maxRtt:"+maxRtt+"ms");
        System.out.println("avrRtt:"+avrRtt+"ms");
        System.out.println("rate:"+rate);
        clientSocket.close();
    }
}