// PingServer.java

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
 * Server to process ping requests over UDP.
 */
public class PingServer {

    public static short byte2Short(byte[] byteNum) {
        short num = 0;
        for (int ix = 0; ix < 2; ++ix) {
            num <<= 8;
            num |= (byteNum[ix] & 0xff);
        }
        return num;
    }

    public static long byte2Long(byte[] byteNum) {
        long num = 0;
        for (int ix = 0; ix < 8; ++ix) {
            num <<= 8;
            num |= (byteNum[ix] & 0xff);
        }
        return num;
    }

    public static String getNumber(String str) {
        Pattern p = Pattern.compile("(\\d+\\.\\d+)");
        Matcher m = p.matcher(str);
        if (m.find()) {
            str = m.group(1) == null ? "" : m.group(1);
        } else {
            p = Pattern.compile("(\\d+)");
            m = p.matcher(str);
            if (m.find()) {
                str = m.group(1) == null ? "" : m.group(1);
            } else {
                str = "";
            }
        }
        return str;
    }

    private static void printData(DatagramPacket request) {
        byte[] buf = request.getData();
        byte[] temp1 = new byte[4];
        byte[] temp2 = new byte[2];
        byte[] temp3 = new byte[8];
        byte[] temp4 = new byte[request.getLength() - temp1.length - temp2.length - temp3.length];
        System.arraycopy(buf, 0, temp1, 0, temp1.length);
        System.arraycopy(buf, temp1.length, temp2, 0, temp2.length);
        System.arraycopy(buf, temp1.length + temp2.length, temp3, 0, temp3.length);
        System.arraycopy(buf, temp1.length + temp2.length + temp3.length, temp4, 0, request.getLength() - temp1.length - temp2.length - temp3.length);

        String str = new String(temp1);
        short sequence = byte2Short(temp2);
        long timestamp = byte2Long(temp3);
        String passwd = new String(temp4);
        System.out.println("Received from " + request.getAddress().getHostAddress());
        System.out.printf("message:%s %d %d %s", str, sequence, timestamp, passwd);
    } // end of printData

    public static void main(String[] args) throws Exception {
        // Get command line argument.
        //test
        if (args.length != 4) {

            System.out.println("Missing parameters: 4 parameters are required ");

            return;
        }

        int port = Integer.parseInt(args[0]);
        int AVERAGE_DELAY = Integer.parseInt(getNumber(args[2]));
        double LOSS_RATE = Double.parseDouble(getNumber(args[3]));
        String passwd = args[1];

        // Create random number generator for use in simulating
        // packet loss and network delay.
        Random random = new Random();

        // Create a datagram socket for receiving and sending
        // UDP packets through the port specified on the
        // command line.
        DatagramSocket socket = new DatagramSocket(port);

        // Processing loop.
        while (true) {

            // Create a datagram packet to hold in comming UDP packet.
            DatagramPacket request = new DatagramPacket(new byte[1024], 1024);

            // Block until receives a UDP packet.
            socket.receive(request);

            byte[] buf = request.getData();
            byte[] pw = new byte[request.getLength() - 16];
            System.arraycopy(buf, 14, pw, 0, request.getLength() - 16);
            String password = new String(pw);
            if (!passwd.equals(password)) {
                System.out.println("Wrong password.");
                socket.close();
                return;
            }

            // Print the received data, for debugging
            printData(request);

            // Decide whether to reply, or simulate packet loss.
            if (random.nextDouble() < LOSS_RATE) {
                System.out.println("Reply not sent.\n");
                continue;
            }

            //simulate delay
            Timer timer = new Timer();
            ReplyTimer replyTimer = new ReplyTimer();
            replyTimer.Set(socket, request);
            timer.schedule(replyTimer, (long) (random.nextDouble() * 2 * AVERAGE_DELAY));
        } // end of while
    } // end of main
} // end of class

class ReplyTimer extends TimerTask {
    private static DatagramSocket socket;
    private static DatagramPacket request;

    public void Set(DatagramSocket S, DatagramPacket P) {
        socket = S;
        request = P;
    }

    public void run() {
        byte[] buf = request.getData();
        InetAddress clientHost = request.getAddress();
        int clientPort = request.getPort();
        byte[] temp1 = "PINGECHO".getBytes();
        byte[] data = new byte[request.getLength() - 4 + 8];
        System.arraycopy(temp1, 0, data, 0, temp1.length);
        System.arraycopy(buf, 4, data, temp1.length, request.getLength() - 4);
        DatagramPacket reply = new DatagramPacket(data, data.length, clientHost, clientPort);
        try {
            socket.send(reply);
            System.out.println("Reply sent.\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.cancel();
    }
}
