import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Timer;
import java.util.TimerTask;

public class PingClient {

    public static int failed = 0;
    public static long[] RTT = new long[10];
    public static String passwd;
    public static InetAddress address;
    public static int port;
    public static short count = 0;

    public static void main(String[] args) throws Exception {
        if (args.length != 3) {
            System.out.println("Missing parameters: three parameters are required ");
            return;
        }
        String host = args[0];
        passwd = args[2];
        port = Integer.parseInt(args[1]);
        address = InetAddress.getByName(host);
        //Timer, send packet per second
        Timer timer = new Timer();
        SendTimer sendTimer = new SendTimer(
                new FlagStatusListener() {
                    @Override
                    public void flagValueChanged(boolean newFlagValue) {
                        if (newFlagValue) {
                            timer.cancel();
                        }
                    }
                }
        );
        timer.schedule(sendTimer, 0, 1000);
    }
}

interface FlagStatusListener {
    void flagValueChanged(boolean newFlagValue);
}

class SendTimer extends TimerTask {

    private final FlagStatusListener listener;
    private boolean flag = false;

    public static void printInfo() {
        if (PingClient.failed == 10) {
            System.out.println("Unable to connect to the HOST\n");
            return;
        }
        long sum = 0;
        long max_RTT = -1;
        long min_RTT = 1001;
        long avg_RTT;
        double loss;
        for (long x : PingClient.RTT) {
            if (max_RTT < x) {
                max_RTT = x;
            }
            if (min_RTT > x && x != 0) {
                min_RTT = x;
            }
            sum += x;
        }

        avg_RTT = sum / (10 - PingClient.failed);
        loss = PingClient.failed / 10.0;
        System.out.printf("MIN_RTT=%dms MAX_RTT=%dms AVG_RTT=%dms LOSS=%f\n", min_RTT, max_RTT, avg_RTT, loss);

    }

    public static byte[] long2Byte(long num) {
        byte[] byteNum = new byte[8];
        for (int ix = 0; ix < 8; ++ix) {
            int offset = 64 - (ix + 1) * 8;
            byteNum[ix] = (byte) ((num >> offset) & 0xff);
        }
        return byteNum;
    }

    public static long byte2Long(byte[] byteNum) {
        long num = 0;
        for (int ix = 0; ix < 8; ++ix) {
            num <<= 8;
            num |= (byteNum[ix] & 0xff);
        }
        return num;
    }

    public static byte[] short2Byte(short num) {
        byte[] byteNum = new byte[2];
        for (int ix = 0; ix < 2; ++ix) {
            int offset = 16 - (ix + 1) * 8;
            byteNum[ix] = (byte) ((num >> offset) & 0xff);
        }
        return byteNum;
    }

    public static short byte2Short(byte[] byteNum) {
        short num = 0;
        for (int ix = 0; ix < 2; ++ix) {
            num <<= 8;
            num |= (byteNum[ix] & 0xff);
        }
        return num;
    }

    private static void printData(DatagramPacket request) {
        byte[] buf = request.getData();
        byte[] temp1 = new byte[8];
        byte[] temp2 = new byte[2];
        byte[] temp3 = new byte[8];
        byte[] temp4 = new byte[request.getLength() - temp1.length - temp2.length - temp3.length];
        System.arraycopy(buf, 0, temp1, 0, temp1.length);
        System.arraycopy(buf, temp1.length, temp2, 0, temp2.length);
        System.arraycopy(buf, temp1.length + temp2.length, temp3, 0, temp3.length);
        System.arraycopy(buf, temp1.length + temp2.length + temp3.length, temp4, 0, request.getLength() - temp1.length - temp2.length - temp3.length);

        String str = new String(temp1);
        short sequence = byte2Short(temp2);
        long timestamp = byte2Long(temp3);
        String passwd = new String(temp4);
        System.out.println("Received from " + request.getAddress().getHostAddress());
        System.out.printf("message:%s %d %d %s\n", str, sequence, timestamp, passwd);
    } // end of printData

    public void run() {
        //when it executed 10 times, stop Timer
        if (PingClient.count == 10) {
            printInfo();

            boolean oldValue = flag;
            flag = true;
            if (this.listener != null && oldValue != flag) {
                listener.flagValueChanged(flag);
            }
            return;
        }
        //create socket
        DatagramSocket socket = null;
        try {
            socket = new DatagramSocket();
            socket.setSoTimeout(1000);
        } catch (SocketException e) {
            e.printStackTrace();
        }
        PingClient.RTT[PingClient.count] = 0;
        //create DatagramPacket, and send.
        byte[] temp1 = "PING".getBytes();
        byte[] temp2 = short2Byte(PingClient.count);
        byte[] temp4 = (PingClient.passwd + "\r\n").getBytes();
        long send_time = System.currentTimeMillis();
        byte[] temp3 = long2Byte(send_time);
        byte[] data = new byte[temp1.length + temp2.length + temp3.length + temp4.length];
        System.arraycopy(temp1, 0, data, 0, temp1.length);
        System.arraycopy(temp2, 0, data, temp1.length, temp2.length);
        System.arraycopy(temp3, 0, data, temp1.length + temp2.length, temp3.length);
        System.arraycopy(temp4, 0, data, temp1.length + temp2.length + temp3.length, temp4.length);

        try {
            DatagramPacket packet_send = new DatagramPacket(data, data.length, PingClient.address, PingClient.port);
            assert socket != null;
            socket.send(packet_send);

            byte[] data_receive = new byte[1024];
            DatagramPacket packet_receive = new DatagramPacket(data_receive, data_receive.length);
            socket.receive(packet_receive);

            long receive_time = System.currentTimeMillis();
            PingClient.RTT[PingClient.count] = receive_time - send_time;
            System.out.printf("Sequence %d:Reply from %s RTT=%dms\n", PingClient.count, packet_receive.getAddress().getHostAddress(), PingClient.RTT[PingClient.count]);
            printData(packet_receive);
        } catch (Exception e) { //timed out
            System.out.printf("Sequence %d:Request timed out.\n\n", PingClient.count);
            PingClient.failed++;
        }
        PingClient.count++;
        assert socket != null;
        socket.close();
    }

    public SendTimer(FlagStatusListener listener) {
        this.listener = listener;
    }
}
