//PingClient.java

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.net.*;
import java.util.Locale;
import java.util.TimeZone;


public class sender {

    public static void main(String[] args) throws  Exception{
        // Get command line argument.
        String password;
        password=args[0];
        //Record password digits.
        DatagramSocket datagramSocket = new DatagramSocket(7799);
        datagramSocket.setSoTimeout(1000);
        //Set time zone calibration.
        URLConnection conn = new
                URL("http://www.baidu.com").openConnection();
        String dateStr = conn.getHeaderField("Date");
        DateFormat httpDateFormat = new
                SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z", Locale.US);
        httpDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+8"));
        Date date = httpDateFormat.parse(dateStr);

        for(int i=1;i<=10;i++)  //10 times.
        {
            String str;
            if (i<=9)  //Control digit.
                str ="Ping "+i+"   "+date+" "+password+"\n";
            else
                str ="Ping "+i+"  "+date+" "+password+"\n";
            byte[] data=str.getBytes("UTF-8");
            DatagramPacket datagramPacket= new DatagramPacket(data,data.length, InetAddress.getByName("localhost"),8000);
            //Set the port to 8000.
            System.out.print(str+"    ");
            long startTime = System.currentTimeMillis();
            datagramSocket.send(datagramPacket);
            byte[] data1=new byte[1024];
            DatagramPacket datagramPacket1=new DatagramPacket(data1,data1.length);
            try {
                datagramSocket.receive(datagramPacket1);
            } catch (IOException e) {
                System.out.print("超时"+"\n");
                continue;
            }
            long endTime = System.currentTimeMillis();
            //String str1=new String(data1,0,datagramPacket1.getLength(),"UTF-8");
            //System.out.println("reply:"+str1+"  "+(endTime - startTime) + "ms");
            byte[] buf1 = datagramPacket1.getData();
            ByteArrayInputStream bais
                    = new ByteArrayInputStream(buf1);
            InputStreamReader isr
                    = new InputStreamReader(bais,"UTF-8");
            BufferedReader br
                    = new BufferedReader(isr);
            String line = br.readLine();
            System.out.println("reply: "+line + " " +(endTime - startTime) + "ms");
            Thread.sleep(1000-(endTime - startTime));//1s一个
        }

    }
}