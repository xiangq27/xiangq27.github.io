// PingServer.java
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*; 
import java.time.LocalTime;

public class Client{

    public static void main(String[] args) throws Exception {
        //获取命令行参数
        if (args.length < 1) {
            System.out.println("Required arguments: host port password");
            return;
        }

        String serverName = args[0];  
        InetAddress serverIPAddress = InetAddress.getByName(serverName);

        int serverPort = Integer.parseInt(args[1]);//端口号
        String passwd = args[2];//输入密码

        //输出相关数据
        System.out.println("host: " + serverIPAddress);
        System.out.println("port: " + serverPort);
        System.out.println("passwd: " + passwd + "\n");

        
        //创建数据包套接字
        DatagramSocket clientSocket = new DatagramSocket();

        clientSocket.setSoTimeout(100); //设置套接字超时值为1s
        int LostDataCnt = 0; //统计丢包次数
        double[] RTT = new double[12]; 
        for(int i=0;i<10;i++){
            

			
			//记录开始发送的时间
            double sendTime = System.nanoTime(); 

            //计录数据包发送时间
			Date nowTime = new Date();
        	System.out.println(nowTime);

            //定义数据包发送内容
            byte[] sendData = ("PING " + i + " " + nowTime + " " + passwd + "\n\r").getBytes();
            System.out.println("Ping " + i + " sent");

            // construct and send datagram
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverIPAddress, serverPort);
            clientSocket.send(sendPacket);

            try {
                // receive datagram
                byte[] receiveData = new byte[100];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                clientSocket.receive(receivePacket);

                // print output
                String sentenceFromServer = new String(receivePacket.getData());
                System.out.println("Reply From Server: " + sentenceFromServer);
               
                // 服务器返回时间 - 客户机发送时间 = 一次往返时间RTT
                RTT[i] = System.nanoTime() - sendTime;
                RTT[i] /= 1000000L;
            } catch (SocketTimeoutException e) {
                System.out.println("Request TIMEOUT!");
                LostDataCnt += 1;
            }

            //输出本次RTT一次往返时间
            System.out.println("RTT=" + RTT[i]);
            System.out.println("OK\n\n");
            Thread.sleep(1000);//每发送一次休眠1s
			//Timer timer = new Timer();
			//timer.schedule(task,1000);
        }

        double loss_rate = LostDataCnt / 10.0;//计算损失率
        System.out.println("Packet loss: " + LostDataCnt);
        System.out.println("Loss rate：" + loss_rate);

        clientSocket.close(); //关闭套接字

        //计算最小、最大和平均RTT
        double min = 1000,max = -1,sum = 0;
        for(int i = 0; i < 10; i++){
            if(RTT[i] < min && RTT[i] != 0.0)
                min = RTT[i];
            if(RTT[i] > max)
                max = RTT[i];
            sum += RTT[i];
        }

        //输出最小、最大和平均RTT
        double aver;
        //如果数据包全部丢失，将最小、最大和平均RTT设置为0
        if(LostDataCnt == 10){
            min = 0;
            max = 0;
            aver = 0;
        }
        else
            aver = sum / ((10 - LostDataCnt) * 1.0);
        System.out.println("Min RTT：" + min + "ms");
        System.out.println("Max RTT：" + max + "ms");
        System.out.println("Average RTT：" + aver + "ms");
    }
}