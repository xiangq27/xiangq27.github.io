// PingServer.java
import java.io.*;
import java.net.*;
import java.util.*;

/*
服务器通过UDP处理ping请求
*/

public class PingServer{
   private static final double LOSS_RATE = 0.3;  //LOSS_RATE —— 应丢失数据包的百分比
   private static final int AVERAGE_DELAY = 100;  //毫秒级AVERAGE_DELAY —— 模拟传播延迟
   //在同一台机器上测试客户机和服务器时，或者当网络上的机器靠近时，应将AVERAGE_DELAY的值设置为正值
   //可以将AVERAGE_DELAY设置为0，以了解数据包的真实往返时间

   public static void main(String[] args) throws Exception{
      //获取命令行参数
      if (args.length < 1) {
         System.out.println("Required arguments: port password ");
         return;
      }
      
      int port = Integer.parseInt(args[0]);//端口号
      String password = args[1];//接收服务器密码

      //创建用于模拟的随机数生成器
      //数据包丢失和网络延迟
      Random random = new Random();

      //创建一个数据包套接字，用于通过命令行上指定端口接收和发送UDP数据包 
      DatagramSocket socket = new DatagramSocket(port);
      
      //输出端口、密码、丢包率、延迟的相关数据信息
      System.out.println("Server listening port = " + port);
      System.out.println("Server password = " + password);

		
      //处理循环
      while (true) {
         
         //创建一个数据包来保存输入的UDP数据包
         DatagramPacket request = new DatagramPacket(new byte[1024], 1024);
      
         //阻塞，直到收到UDP数据包
         socket.receive(request);
         
         //打印接收到的数据，用于调试
         String recvdata = printData(request);

         //判断密码是否正确
         boolean retVal = recvdata.endsWith(password);
         if(!retVal){
            System.out.println("  Reply not sent. Password error.\n");
            continue;
         }

         //决定是回复还是模拟数据包丢失
         if (random.nextDouble() < LOSS_RATE) {
            System.out.println("  Reply not sent.\n");
            continue;
         }

         //模拟程序延迟
         Thread.sleep((int) (random.nextDouble() * 2 * AVERAGE_DELAY));

         //发送回复 
         InetAddress clientHost = request.getAddress();//返回某台机器的 IP 地址，此数据报将要发往该机器或者从该机器接收。
         int clientPort = request.getPort();//返回某台远程主机的端口号，此数据报将要发往该主机或者从该主机接收
         byte[] buf = recvdata.replaceFirst("PING", "PINGECHO").getBytes();//将发送过来的数据包前缀进行替换作为回复数据包的内容
         DatagramPacket reply = new DatagramPacket(buf, buf.length, clientHost, clientPort);
        
         socket.send(reply);
        
         System.out.println("  Reply sent.\n");
      } //循环结束
   
   } // 主函数结束

/*
将ping数据打印到标准输出流
*/
 
   private static String printData(DatagramPacket request) 
         throws Exception
         {
        //获取对数据包字节数组的引用
         byte[] buf = request.getData();

         //将字节包装到字节数组输入流中，以便以字节流的形式读取数据
         ByteArrayInputStream bais 
           = new ByteArrayInputStream(buf);

         //流读取器
         InputStreamReader isr 
           = new InputStreamReader(bais);

         //将输入流读取器包装在buffered读取器中，以便一次读取一行字符数据
         //一行（由\r和\n的任意组合终止的字符序列）
         BufferedReader br 
           = new BufferedReader(isr);

         //消息包括在一行中
         String line = br.readLine();

         String data = new String(line);
         //打印主机地址和接收到的数据
         System.out.println("Received from " +         
            request.getAddress().getHostAddress() +
            ": " +
            data);

         return data;
   }//打印结束
} //结束