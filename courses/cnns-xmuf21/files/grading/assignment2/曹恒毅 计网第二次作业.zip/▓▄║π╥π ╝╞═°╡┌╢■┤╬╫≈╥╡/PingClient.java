import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;

 
public class PingClient extends Thread{
	private DatagramSocket client;
	private InetAddress hostAddress;
	private int port;
	private int replyNum1 = 0, replyNum2 = 0;
	private long minRtt1 = 0, maxRtt1 = 0, avgRtt1 = 0,sumRtt1 = 0;
	private long minRtt2 = 0, maxRtt2 = 0, avgRtt2 = 0,sumRtt2 = 0;
	private long daikuan = 0;
	private long[] rtt = new long[20];
	public PingClient(String host, int port) 
	{

		if(port < 0 || port > 60000) 
		{
			System.out.println("Please input right port number!");
			System.exit(0);
		}
		this.port = port;
		try
		{
			client = new DatagramSocket();
			hostAddress = InetAddress.getByName(host);
		} 
		catch (SocketException e) 
		{
			e.printStackTrace();
		} 
		catch (UnknownHostException e) 
		{
			System.out.println("Please input right host name!");
			e.printStackTrace();
		}	
	}
	

	public void run() 
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SS");	
		System.out.println("Ping " + hostAddress + ":");
		for(int i=0; i<10; i++) 
		{
			Date sendTime = new Date();
			String outMessage = "PING " + i +" "+ sdf.format(sendTime)+" passwd" + "\n" ;		
			byte[] buffer = outMessage.getBytes();
			DatagramPacket sendPacket = new DatagramPacket(buffer,buffer.length,hostAddress,port);
			byte[] buf = new byte[buffer.length];		
			DatagramPacket recievePacket = new DatagramPacket(buf,buf.length);
			String recieve = null;
			try 
			{
				client.send(sendPacket);
				client.setSoTimeout(1000);
				client.receive(recievePacket);
				recieve = new String(recievePacket.getData());
				Date recieveTime = new Date();
				rtt[i] = recieveTime.getTime()-sendTime.getTime();
			} 
			catch (IOException e) 
			{
				rtt[i]=1010;
			}
			if(rtt[i]>1000) 
			{
				recieve = "PING " + i +" "+ sdf.format(sendTime)+" passwd" + "\n" 
						+ "Response message lost!";
						
			}
			else 
			{
				recieve = recieve + "\n" + "rtt:" + rtt[i] +"ms";
			}
			System.out.println(recieve);			
		}
		for(int i=10; i<20; i++) 
		{
			Date sendTime = new Date();
			String outMessage = "PINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPINGPING " + i +" "+ sdf.format(sendTime)+" passwd" + "\n" ;		
			byte[] buffer = outMessage.getBytes();
			DatagramPacket sendPacket = new DatagramPacket(buffer,buffer.length,hostAddress,port);
			byte[] buf = new byte[buffer.length];		
			DatagramPacket recievePacket = new DatagramPacket(buf,buf.length);
			String recieve = null;
			try 
			{
				client.send(sendPacket);
				client.setSoTimeout(2000);
				client.receive(recievePacket);
				recieve = new String(recievePacket.getData());
				Date recieveTime = new Date();
				rtt[i] = recieveTime.getTime()-sendTime.getTime();
			} 
			catch (IOException e) 
			{
				rtt[i]=2010;
			}
			if(rtt[i]>2000) 
			{
				recieve = "PING " + i +" "+ sdf.format(sendTime)+" passwd" + "\n" 
						+ "Response message lost!";
						
			}
			else 
			{
				recieve = recieve + "\n" + "rtt:" + rtt[i] +"ms";
			}
			System.out.println(recieve);			
		}
		minRtt1 = rtt[0];
		for(int i=0;i<10;i++) 
		{
			if(rtt[i] > 1000)  continue;
			replyNum1++;	
			if(minRtt1 > rtt[i]) 
			{
				minRtt1 = rtt[i];
			}
			if(maxRtt1 < rtt[i]) 
			{
				maxRtt1 = rtt[i];
			}
			sumRtt1 += rtt[i];
		}
		minRtt2 = rtt[10];
		for(int i=10;i<20;i++) 
		{
			if(rtt[i] > 2000)  continue;
			replyNum2++;	
			if(minRtt2 > rtt[i]) 
			{
				minRtt2 = rtt[i];
			}
			if(maxRtt2 < rtt[i]) 
			{
				maxRtt2 = rtt[i];
			}
			sumRtt2 += rtt[i];
		}
		if(replyNum1!=0) 
		{
			avgRtt1 = sumRtt1/replyNum1;
			System.out.println("Packets: Sent=10, Received=" + replyNum1 +", Lost=" + (10-replyNum1)+",loss rate=0."+(10-replyNum1));
			System.out.println("minRTT1:" + minRtt1 + "ms, maxRTT1:" + maxRtt1 + "ms, averRTT1:" + avgRtt1 + "ms");
		}
		else 
		{
			System.out.println("Failed to send request! Unable to return message!");
		}
		if(replyNum2!=0) 
		{
			avgRtt2 = sumRtt2/replyNum2;
			System.out.println("Packets: Sent=10, Received=" + replyNum2 +", Lost=" + (10-replyNum2)+",loss rate=0."+(10-replyNum2));
			System.out.println("minRTT2:" + minRtt2 + "ms, maxRTT2:" + maxRtt2 + "ms, averRTT2:" + avgRtt2 + "ms");
		}
		else 
		{
			System.out.println("Failed to send request! Unable to return message!");
		}
		daikuan = 100*8/(avgRtt2-avgRtt1);
		System.out.println("Band Width = "+ daikuan +" Mbps");
		client.close();
	}
	
	public static void main(String[] args) 
	{
	int passwd = 123;
	if(args.length != 3)
	{
		System.out.println("Please input passwd!");
		return;
	}
	int inputpasswd = Integer.parseInt(args[2]);
	if(inputpasswd != passwd)
	{
		System.out.println("Wrong Passwd!");
		return;
	}
		PingClient clientThread = new PingClient(args[0], Integer.valueOf(args[1]));
		clientThread.start();
	}

}
