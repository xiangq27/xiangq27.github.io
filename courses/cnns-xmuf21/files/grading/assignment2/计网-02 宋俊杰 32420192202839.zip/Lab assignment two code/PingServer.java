// PingServer.java
   import java.io.*;
   import java.net.*;
   import java.util.*;
   import java.text.DateFormat;
   import java.text.SimpleDateFormat;
   import org.apache.commons.net.ntp.*;

   /* 
   * Server to process ping requests over UDP.
   */
      
   public class PingServer
   {
      private static final double LOSS_RATE = 0.3;
      private static final int AVERAGE_DELAY = 100; // milliseconds

      public static void main(String[] args) throws Exception
      {
         // Get command line argument.
         if (args.length != 2) {
            System.out.println("Required arguments: port password");
            return;
         }

         int port = Integer.parseInt(args[0]);
         // Create random number generator for use in simulating packet loss and network delay.
         Random random = new Random();
         // Create a datagram socket for receiving and sending UDP packets through the port specified on the command line.
         DatagramSocket socket = new DatagramSocket(port);
         // Processing loop.
         while (true) {
            // Create a datagram packet to hold incomming UDP packet.
            DatagramPacket request = new DatagramPacket(new byte[1024], 1024);
            // Block until receives a UDP packet.
            socket.receive(request);
            NTPUDPClient timeClient = new NTPUDPClient();
            String timeServerUrl = "130.149.17.21";
            InetAddress timeServerAddress = InetAddress.getByName(timeServerUrl);
            TimeInfo timeInfo = timeClient.getTime(timeServerAddress);
            TimeStamp timeStamp = timeInfo.getMessage().getTransmitTimeStamp();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
            System.out.println("Reach Time：" + dateFormat.format(timeStamp.getDate()));
            String lastWord = printData(request);
            if(!lastWord.equals(args[1])) {
            System.out.println("Passwd Wrong!");
            continue;
            }
            // Decide whether to reply, or simulate packet loss.
            if ((random.nextDouble() < LOSS_RATE)) {
               System.out.println(" Reply not sent.");
               continue;
            }
            // Simulate prorogation delay.
            Thread.sleep((int) (random.nextDouble() * 2 * AVERAGE_DELAY));
            // Send reply.
            InetAddress clientHost = request.getAddress();
            int clientPort = request.getPort();
            byte[] buf = request.getData();
            DatagramPacket reply = new DatagramPacket(buf, request.getLength(), clientHost, clientPort);
            socket.send(reply);
            //！！注意getLength()和getData().length长度的区别
            System.out.println(" Reply sent.");
         } // end of while
      } // end of main
      /* 
      * Print ping data to the standard output stream.
      */
      private static String printData(DatagramPacket request) throws Exception
      { 
         // Obtain references to the packet's array of bytes.
         byte[] buf = request.getData();
         ByteArrayInputStream bais = new ByteArrayInputStream(buf);
         InputStreamReader isr = new InputStreamReader(bais,"UTF-8");
         BufferedReader br = new BufferedReader(isr);
         String line = br.readLine();
         System.out.println("Received from " + request.getAddress().getHostAddress() + ":" + new String(line) );
         String lastWord = line.substring(line.lastIndexOf(" ") + 1 );
         return lastWord ;
      } // end of printData
      
   } // end of class