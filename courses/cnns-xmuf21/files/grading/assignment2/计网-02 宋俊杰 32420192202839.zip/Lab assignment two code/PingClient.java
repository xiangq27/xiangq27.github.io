import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.apache.commons.net.ntp.*;
public class PingClient {
	public static void main(String[] args)throws Exception {
		if(args.length==0) {
			System.out.println("Required argument:Host port");
			return;
		}
		if(args.length==1) {
			System.out.println("Required argument: port");
			return;
		}
		String host=args[0].toString();
		int port = Integer.parseInt(args[1]);
		DatagramSocket clientSocket = new DatagramSocket();
		clientSocket.setSoTimeout(1000);
		InetAddress IPAddress=InetAddress.getByName(host);
		long sendTime,receiveTime;
		//////////////////////////
		int NoReply = 0;
		double rate = 0.0;
		int size = 10;
		long[] latencylist = new long[size];
		int j = 0;
		//////////////////////////
		for(int i=0;i<10;i++) {
			byte[] sendData=new byte[1024];
			byte[] receiveData=new byte[1024];
			String passwd = args[2];
			
			NTPUDPClient timeClient = new NTPUDPClient();
			String timeServerUrl = "130.149.17.21";
			InetAddress timeServerAddress = InetAddress.getByName(timeServerUrl);
			TimeInfo timeInfo = timeClient.getTime(timeServerAddress);
			TimeStamp timeStam = timeInfo.getMessage().getTransmitTimeStamp();
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			String timeStamp = dateFormat.format(timeStam.getDate());
			
			String pingMessage= "PING"+" "+i+" "+timeStamp+" "+passwd+"\r\n";
			sendData = pingMessage.getBytes("UTF-8");
			DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length,IPAddress,port);
			try {
				sendTime = System.currentTimeMillis();	//dot 1
				clientSocket.send(sendPacket);
				DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
				clientSocket.receive(receivePacket);
				receiveTime =System.currentTimeMillis();	//dot 2
				long latency = receiveTime-sendTime;
				String serverAddress= receivePacket.getAddress().getHostAddress();
				System.out.println("From"+" "+serverAddress+":"+latency+"ms");
				System.out.println("PINGECHO"+" "+i+" "+timeStamp+" "+passwd+" ");
				latencylist[j++] = latency;
			}catch(java.net.SocketTimeoutException ex){
				NoReply = NoReply + 1;
				String reply="No reply";
				System.out.println(reply);
			}
		}
		long maxvalue = latencylist[0];
		for(int k=1;k<j;k++) {
			if(maxvalue < latencylist[k]) {
				maxvalue = latencylist[k];
			}
		}
		long minvalue = latencylist[0];
		for(int k=1;k<j;k++) {
			if(minvalue > latencylist[k]) {
				minvalue = latencylist[k];
			}
		}
		long sum = 0;
		double avg = 0.0;
		for(int k=0;k<j;k++) {
			sum = sum + latencylist[k];
		}
		avg = 1.0 * sum / j;
		avg = (double)Math.round(avg*100)/100;
		rate = 1.0 * NoReply / 10;
		System.out.println("max rtt:"+maxvalue+"ms"+" "+"min rtt:"+minvalue+"ms"+" "+"average rtt:"+avg+"ms"+" "+"the loss rate:"+rate);
		clientSocket.close();
	}

}