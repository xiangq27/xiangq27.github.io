// PingClient.java
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

/*
 * Client to send ping requests over UDP.
 */

public class PingClient {
    public static void main(String[] args) throws Exception
    {
        // Get command line argument.
        if (args.length != 3) {
            System.out.println("Required arguments: host name, port, passwd");
            return;
        }
        // host port passwd
        String host = args[0].toString();
        int port = Integer.parseInt(args[1]);
        String passwd = args[2];

        // Create an array to store RTTs.
        int[] rtt = new int[10];
        int r = 0;

        // Create a datagram socket for receiving and sending
        // UDP packets through the port specified on the
        // command line.
        DatagramSocket ClientSocket = new DatagramSocket();

        // Send 10 ping requests to the server, at a pace of one request per second.
        // After sending each request, the client waits up to one second to recieve a reply.
        // If one second goes by without a reply from the server, then print " No reply. "
        ClientSocket.setSoTimeout(1000);
        for (int i=0; i<10; i++)
        {
            // Get client_send_time
            Date currenTime = new Date();
            String strDateFormat = "yyyy-MM-dd HH:mm:ss";  // Format time.
            SimpleDateFormat sdf = new SimpleDateFormat(strDateFormat);
            String timeStamp = sdf.format(currenTime);

            // Ping message format from a client to the server.
            String ping = "PING " + i + " " + timeStamp + " " + passwd + "\r\n";

            // Cate a datagram packet to send ping requests.
            byte[] sendPacket = new byte[1024];
            sendPacket = ping.getBytes(StandardCharsets.UTF_8);
            DatagramPacket pingRequest = new DatagramPacket(sendPacket, sendPacket.length,
                                                InetAddress.getByName(host), port);
            try {
                // Send time.
                long sendTime = System.currentTimeMillis();
                // Send ping.
                ClientSocket.send(pingRequest);
                // Recieve reply.
                DatagramPacket replyReceive = new DatagramPacket(new byte[1024], 1024);
                ClientSocket.receive(replyReceive);
                // Recieve time.
                long recieveTime = System.currentTimeMillis();
                // RTT lculate.
                int delay = (int) (recieveTime - sendTime);
                rtt[r] = delay;
                r++;
                printData(replyReceive);
            } catch(java.net.SocketTimeoutException ex)
            {
                // Assume that either its request or the server's reply has been lost in the network.
                System.out.println("No reply.");
            }
        } // end of for

        // Report the minimun, maximum, and average RTTs.
        Arrays.sort(rtt);
        // System.out.println(Arrays.toString(rtt));  // print
        // System.out.println("r="+r);
        double sum = 0;
        double avera;
        for (int k=10-r; k<10; k++) {
            sum += rtt[k];
        }
        avera = sum / rtt.length;
        System.out.println("The minimum RTT is " + rtt[10-r] + "ms");
        System.out.println("The maximum RTT is " + rtt[9] + "ms");
        System.out.println("The average RTT is " + avera + "ms");

        // Report loss rate.
        double lossRate = 1 - (double)r / 10;
	double get_double = Double.parseDouble(String.format("%.2f", lossRate));
        System.out.println("The loss rate is " + get_double);

        // Close socket.
        ClientSocket.close();
    } // end of main
    /*
     * Print pingecho data to the standard output stream.
     */
    private static void printData(DatagramPacket reply) throws Exception
    {
        // Obtain references to the packet's array of bytes.
        byte[] buf = reply.getData();

        // Wrap the bytes in a byte array input stream, so that you can read the data as a stream of bytes.
        ByteArrayInputStream bais = new ByteArrayInputStream(buf);

        // Wrap the byte array output stream in an input stream reader, so you can read the data as a
        // stream of **characters**: reader/writer handles characters
        InputStreamReader isr = new InputStreamReader(bais);

        // Wrap the input stream reader in a bufferred reader, so you can read the character data a line at a time.
        // (A line is a sequence of chars terminated by any combination of \r and \n.)
        BufferedReader br = new BufferedReader(isr);

        // The message data is contained in a single line, so read this line.
        String line = br.readLine();

        // Print host address and data received from it.
        System.out.println("Received from " + reply.getAddress().getHostAddress() + ": " + new String(line) );
    }
} // end of class

