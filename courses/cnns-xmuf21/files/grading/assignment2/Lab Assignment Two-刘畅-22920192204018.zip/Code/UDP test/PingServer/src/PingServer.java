// PingServer.java
import java.io.*;
import java.net.*;
import java.util.*;

/*
 * Server to process ping requests over UDP.
 */

public class PingServer
{
    private static double LOSS_RATE = 0.3;
    private static final String password = "hadoop";
    private static int AVERAGE_DELAY = 100; // milliseconds
    public static void main(String[] args) throws Exception
    {
        // Get command line argument.
        if (args.length < 1) {
            System.out.println("Required arguments: port");
            return;
        }
        int port = Integer.parseInt(args[0]);
        if (args.length < 2) {
            System.out.println("Required arguments: password");
            return;
        }
        //Check the password
        String psw = args[1];
        if (!psw.equals(password))
        {
            System.out.println("Password error");
            return;
        }

        //Set new delay
        if(args.length == 3)
        {
            AVERAGE_DELAY = Integer.parseInt(args[2]);
        }
        //Set new delay and loss
        if(args.length == 4)
        {
            AVERAGE_DELAY = Integer.parseInt(args[2]);
            LOSS_RATE = Double.parseDouble((args[3]));
        }

        System.out.println("The server is running");
        // Create random number generator for use in simulating
        // packet loss and network delay.
        Random random = new Random();
        // Create a datagram socket for receiving and sending
        // UDP packets through the port specified on the
        // command line.
        DatagramSocket socket = new DatagramSocket(port);
        int count =1;
        // Processing loop.
        while (true) {

            // Create a datagram packet to hold incomming UDP packet.
            DatagramPacket
                    request = new DatagramPacket(new byte[1024], 1024);

            // Block until receives a UDP packet.
            socket.receive(request);
            //to check the password from the Client
            int judge;
            judge = printData(request);
            if (judge == 0)
            {
                System.out.println(" Password error,reply not sent.");
                System.out.printf("\n");
                count++;
                continue;
            }
            // Decide whether to reply, or simulate packet loss.
            if (random.nextDouble() < LOSS_RATE) {
                System.out.println(" Reply not sent.");
                System.out.printf("\n");
                count++;
                continue;
            }

            // Simulate prorogation delay.
            Thread.sleep((int) (random.nextDouble() * 2 * AVERAGE_DELAY));

            // Send reply.
            InetAddress clientHost = request.getAddress();
            int clientPort = request.getPort();
            byte[] buf ;

            //get time
            byte[] buf1 = request.getData();
            ByteArrayInputStream bais
                    = new ByteArrayInputStream(buf1);
            InputStreamReader isr
                    = new InputStreamReader(bais,"UTF-8");
            BufferedReader br
                    = new BufferedReader(isr);
            String line = br.readLine();
            String time = line.substring(8,22);

            if (count<10) {
                buf = ("PINGECHO" + " " + count + "  " + time + " " + psw +"\n").getBytes();
            }
            else {
                buf = ("PINGECHO" + " " + count + " " + time + " " + psw + "\n").getBytes();
            }
            DatagramPacket
                    reply = new DatagramPacket(buf, buf.length,
                    clientHost, clientPort);
            socket.send(reply);
            System.out.printf(" PINGECHO %-2d %s %s\n\n",count++,time,password);
        } // end of while
    } // end of main

    /*
     * Print ping data to the standard output stream.
     */
    private static int printData(DatagramPacket request)
            throws Exception
    {
        // Obtain references to the packet's array of bytes.
        byte[] buf = request.getData();
        ByteArrayInputStream bais
                = new ByteArrayInputStream(buf);

        InputStreamReader isr
                = new InputStreamReader(bais,"UTF-8");

        BufferedReader br
                = new BufferedReader(isr);

        String line = br.readLine();
//        System.out.println(line);
        String psw0 = line.substring(22);
        if (!psw0.equals(password))
        {
            System.out.println("Received from " +
                    request.getAddress().getHostAddress() +
                    ": " +
                    new String(line) );
            return 0;
        }
//        System.out.print(psw0);
//        System.out.println(password);
        // Print host address and data received from it.
        System.out.println("Received  from " +
                request.getAddress().getHostAddress() +
                ": " +
                new String(line) );
        return 1;
    } // end of printData
} // end of classa