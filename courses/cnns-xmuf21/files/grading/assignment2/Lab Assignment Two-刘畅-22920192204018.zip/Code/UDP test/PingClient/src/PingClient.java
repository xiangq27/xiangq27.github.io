import java.io.IOException;
import  java.util.*;
import java.net.*;

public class PingClient {
    private static long Max=-1;
    private static long Min=9999;
    private static long count_RTT=0;
    private static long sum=0;
    public static void main(String[] args) throws IOException, InterruptedException {


        //password to connect the server
        String psw;
        if (args.length < 1) {
            System.out.println("Required arguments: password");
            return;
        }

        else psw = args[0];
        TimeZone.setDefault(TimeZone.getTimeZone("GMT+8")); // 时区设置
        URL url=new URL("http://www.ntsc.ac.cn");//取得资源对象
        URLConnection uc=url.openConnection();//生成连接对象
        uc.connect(); //发出连接
        long ld=uc.getDate(); //取得网站日期时间（时间戳）


        int count = 1;
        while(count <= 10)
        {
            if (count!=1)
            {
                ld +=1000;
            }
            //创建接受或发送的数据报套接字，并指定发送方的端口号为7799
            DatagramSocket ds = new DatagramSocket(7799);   //端口号也可以不指定
            //System.out.println("---发送方---");

            //创建数据报对象，用来发送数据
            byte[] b = "hello Lee ！".getBytes();
            if (count<10) {
                b = ("Ping" + " " + count + "  " + ld + " " + psw +"\n").getBytes();
            }
            else {
                b = ("Ping" + " " + count + " " + ld + " " + psw + "\n").getBytes();
            }
            //DatagramPacket dp = new DatagramPacket(b, b.length, InetAddress.getByName("10.30.35.14"), 7788);
            DatagramPacket dp = new DatagramPacket(b, b.length, InetAddress.getByName("localhost"), 7788);
            long start = System.currentTimeMillis();
            ds.send(dp);    //发送数据包
            System.out.printf("\nPing %-2d %d %s\n",count++,ld,psw);

            DatagramPacket dp1 = new DatagramPacket(new byte[1024], 1024);
            try {
                //设置超时时间,1秒
                ds.setSoTimeout(1000);
                ds.receive(dp1);
                System.out.print("get reply\t");
            } catch (Exception e) {
                System.out.println("no reply");
            }

            long end = System.currentTimeMillis();
            long dd = end - start;
            if(dd<1000)
            {
                System.out.printf("RTT:%dms\n",dd);
                if (dd > Max) Max = dd;
                if (dd < Min) Min = dd;
                sum += dd;
                count_RTT++;
                Thread.sleep(1000-dd);
            }
            //关闭流
            ds.close();
        }

        //to show some detail
        double ave,los;
        ave = (double)sum/count_RTT;
        los = (10-count_RTT)/10.0*100;
        System.out.printf("\nThe maximum of RTT is:%d\nThe minimum of RTT is:%d\nThe average of RTT is:%f\nThe loss rate is:%.1f%%\n",
                Max,Min,ave,los);
    }

}

