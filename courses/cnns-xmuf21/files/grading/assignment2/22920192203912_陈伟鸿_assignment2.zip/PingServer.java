// PingServer.java
    import java.io.*;
    import java.net.*;
    import java.util.*;

    /* 
     * Server to process ping requests over UDP.
     */
        
    public class PingServer
    {
       private static final double LOSS_RATE = 0.3;
       private static final int AVERAGE_DELAY = 100; // milliseconds
       private static final int keys = 3912;
       public static void main(String[] args) throws Exception
       {
          // Get command line argument.
          if (args.length != 2) {
             System.out.println("Required arguments: port or keys");

             return;
          }

          int port = Integer.parseInt(args[0]);
          int passwd = Integer.parseInt(args[1]);

          if(passwd != keys){
             System.out.println("wrong keys!\n");
             return ;
          }
          // Create random number generator for use in simulating
          // packet loss and network delay.
          // 创建随机数生成器，用于模拟数据包丢失和网络延迟。
          Random random = new Random();

          // Create a datagram socket for receiving and sending
          // UDP packets through the port specified on the
          // command line.
          // 用于通过命令行指定的端口接收和发送UDP包
          DatagramSocket socket = new DatagramSocket(port);
          
          // Processing loop.
          int i = 0;
          Date SRTime1 = new Date(),SRTime2;
          while (true) {
             //声明一个date类型的数组，用于储存接收的时间
             i++;
             // Create a datagram packet to hold incomming UDP packet.保存传入的UDP报文
             DatagramPacket
                request = new DatagramPacket(new byte[1024], 1024);
             // Block until receives a UDP packet.阻塞，直到收到UDP报文。

             
             socket.receive(request);

             int Packetbytes = returnActualLength(request);

             // Print the received data, for debugging
             byte[] buf = request.getData();

            // 计算带宽
            //  if(i % 10 == 5)
            //     {
            //        SRTime1 = new Date();//计算第一个数据包的到达时间
            //     }
            //  if(i % 10 == 6)
            //     {
            //        SRTime2 = new Date();//计算第二个数据包的到达时间
            //        long b1_b0 = SRTime2.getTime() - SRTime1.getTime();
            //       //  System.out.println("\n" + Packetbytes + "\n");
            //        long bw = Packetbytes * 8 * 1000 / b1_b0;
            //        System.out.println("\nthe receive bandwidth: " + bw + "bps\n" );
            //     }


            //  System.out.println("\nthe ServerRecieve time : " + ServerRecieveTime + "\n");
             
             ByteArrayInputStream bais = new ByteArrayInputStream(buf);
             InputStreamReader isr = new InputStreamReader(bais);
             BufferedReader br = new BufferedReader(isr);
             String line = br.readLine();
             String initrequest = new String(line);
             String strreply = initrequest.replace("PING","PINGECHO");
             System.out.println(initrequest);
            //  printData(request);

             // Decide whether to reply, or simulate packet loss.决定是回复还是模拟丢包。
             if (random.nextDouble() < LOSS_RATE) {
                System.out.println(" Reply not sent.");//丢包
                continue;
             }

             // Simulate prorogation delay.模拟延迟
             Thread.sleep((int) (random.nextDouble() * 2 * AVERAGE_DELAY));

             // Send reply.
             InetAddress clientHost = request.getAddress();
             int clientPort = request.getPort();
             byte[] buff = strreply.getBytes();
             DatagramPacket reply = new DatagramPacket(buff, buff.length,clientHost, clientPort);
        
             socket.send(reply);
             
             Date ServerSendTime = new Date();
            //  System.out.println("\nthe ServerSend time : " + ServerSendTime + "\n");
             
             System.out.println(" Reply sent.");//回复
         } // end of while
       } // end of main
       public static int returnActualLength(DatagramPacket sendPacket) {//计算数据包字节数
         byte[] data = sendPacket.getData();
         int i = 0;
         for (; i < data.length; i++) {
             if (data[i] == '\0')
                 break;
         }
         return i;
       }
    } // end of class
