import java.io.*;
import java.net.*;
import java.util.*;
import java.text.*;

public class PingClient extends Thread{
    private DatagramSocket client;   //server socker
    private InetAddress hostAddress; //ip
    private int port;
    private int replyNum = 0;        //initial reply num
    private long minRTT = 0,maxRTT = 0,averRTT = 0,sumRTT = 0;
    private double lossRate = 0;
    private long[] RTT = new long[10];
    private int Packetbytes = 0;
    private int keys = 3912;  //密码


    public PingClient(String host,int port,int passwd) {
        if (passwd != keys) {
            System.out.println("Wrong password!");
            System.exit(0);
        }
        this.port = port;
        try {
            client = new DatagramSocket();
            hostAddress = InetAddress.getByName(host);
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }
    public void run(){
        System.out.println("Pinging " + hostAddress + ":");
        for(int i=0;i<10;++i){
            Date sendTime = new Date();
            String outMessage = "PING " + i + "\t" + sendTime + "\t" + keys + "\n";
            byte[] buffer = outMessage.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(buffer,buffer.length,hostAddress,port);
            
            Packetbytes = returnActualLength(sendPacket);
            // System.out.println("\n the packet bytes :" + Packetbytes + " \n");

            byte[] buf = new byte[buffer.length + 4];//因为PINGECHO比PING多了4位
            DatagramPacket recievePacket = new DatagramPacket(buf,buf.length);

            String recieve = null;
            try{
                client.send(sendPacket);
                client.setSoTimeout(1000);
                client.receive(recievePacket);
                recieve = new String(recievePacket.getData());
                Date recieveTime = new Date();
                RTT[i] = recieveTime.getTime()-sendTime.getTime();
            }catch (IOException e){
                //e.printStackTrace();
                recieve = "Ping to Server " + i + " failed! reasom:timeout!";
                RTT[i] = 1001;//手动置为1001ms
            }
            recieve = recieve + "\n" + "RTT:" + RTT[i] +"ms";
            System.out.println(recieve);
        }
        minRTT = RTT[0];
        maxRTT = RTT[0];

        // long bandwidth;
        // if(RTT[5]>RTT[6]){
        //     bandwidth = Packetbytes * 8 * 1000 / RTT[5]-RTT[6];
        // }
        // else{
        //     bandwidth =Packetbytes * 8 * 1000 / RTT[6]-RTT[5];
        // }

        for (int i=0;i<10;++i){
            if (RTT[i]>1000) {continue;}
            replyNum ++;
            if (minRTT > RTT[i])
                minRTT = RTT[i];
            if (maxRTT < RTT[i])
                maxRTT = RTT[i];
            sumRTT += RTT[i];
        }//得出最大RTT和最小RTT
        if (replyNum != 0){
            averRTT = sumRTT/replyNum;
            lossRate = (10 - replyNum)/10.0;
            System.out.println("\nmax RTT\t\tmin RTT\t\taverage RTT");
            System.out.println(maxRTT + "ms\t\t" + minRTT + "ms\t\t" + averRTT + "ms");
            System.out.println("loss rate: "+ lossRate);
            // System.out.println("the sent bandwidth: " + bandwidth + "bps\n");
        }else {
            System.out.println("Failed to send request!Unable to return message!");
        }
        client.close();
    }
    public static int returnActualLength(DatagramPacket sendPacket) {//计算数据包字节数
         byte[] data = sendPacket.getData();
         int i = 0;
         for (; i < data.length; i++) {
             if (data[i] == '\0')
                 break;
         }
         return i;
    }
    public static void main(String[] args) {
        PingClient clientThread = new PingClient(args[0],Integer.valueOf(args[1]),Integer.valueOf(args[2]));
        clientThread.start();
    }
}
